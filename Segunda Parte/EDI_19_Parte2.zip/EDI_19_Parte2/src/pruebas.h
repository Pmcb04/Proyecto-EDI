#ifndef PRUEBAS_H_
#define PRUEBAS_H_

#include <fstream>
#include <iostream>
#include "pruebasAlgoritmos.h"
#include "pruebasBarrios.h"
#include "pruebasVias.h"
#include "pruebaSetBarrios.h"
#include "pruebaSetVias.h"
using namespace std;

//Llamada a todas las pruebas realizadas
void pruebas(SetBarrios *&cjtoBarrios);



#endif /* PRUEBAS_H_ */
