/*
 * Arbol.cpp
 *
 *  Created on: 18 feb. 2019
 *      Authors:  - Pedro Miguel Carmona Broncano
 									- Ruben Marin Lucas
 */

#include "Arbol.h"
#include <fstream>


Arbol::Arbol(){

  especie = "";
  familia = "";
  nombreComun = "";
  genero = "";
  riego = "";
  diametro = 0.0;
  altura = 0.0;
  copa = 0.0;
  unidades = 0;
  codigoVia = 0;

}

void Arbol::setEspecie(string especie){

  this->especie = especie;
}

void Arbol::setFamilia(string familia){

  this->familia = familia;
}
void Arbol::setNombreComun(string nombreComun){

  this->nombreComun = nombreComun;
}
void Arbol::setGenero(string genero){

  this->genero = setGenero;
}
void Arbol::setRiego(string riego){

  this->riego = riego;
}
void Arbol::setDiametro(string diametro){

  this->diametro = diametro;
}
void Arbol::setAltura(string altura){

  this->altura = altura;
}
void Arbol::setCopa(string copa){

  this->copa = copa;
}
void Arbol::setUnidades(string unidades){

  this->unidades = unidades;
}
void Arbol::setCodigoVia(string codigoVia){

  this->codigoVia = codigoVia;
}
void Arbol::getEspecie(){
  return especie;
}
void Arbol::getFamilia(){
  return familia;
}
void Arbol::getNombreComun(){
  return nombreComun;
}
void Arbol::getGenero(){
  return genero;
}
void Arbol::getRiego(){
  return riego;
}
void Arbol::getDiametro(){
  return diametro;
}
void Arbol::getAltura(){
  return altura;
}
void Arbol::getCopa(){
  return copa;
}
void Arbol::getUnidades(){
  return unidades;
}
void Arbol::getCodigoVia(){
  return codigoVia;
}
