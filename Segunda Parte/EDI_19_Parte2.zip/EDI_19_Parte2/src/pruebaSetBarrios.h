/*
 * pruebaSetBarrios.h
 *
 *  Created on: 25 mar. 2019
 *      Author: ruben
 */

#ifndef PRUEBASETBARRIOS_H_
#define PRUEBASETBARRIOS_H_

#include "SetBarrios.h"


/*

1º Se construye el conjunto de barrios, ademas de 3 barrrios que se insertarán en este.


2º Se hace comprobaciones como:

     - Que el conjunto no este vacio despues de insertar
     - que el conjunto no esté lleno antes de insertar
     - que el nº de elementos no sea distinto de 3 en nuestro caso
     - comprobacion de los nombres de los 3 barrios
     - se comprueba que dichos barrios se han insertado siguiendo el orden alfabetico correcto
     - eliminacion de un barrio y comprobacion de que no existe en el conjunto despues del borrado
     - eliminacion de todos los barrios restantes y comprobación de que el conjunto está vacio de nuevo

*/

void pruebaSetBarrios();


#endif /* PRUEBASETBARRIOS_H_ */
