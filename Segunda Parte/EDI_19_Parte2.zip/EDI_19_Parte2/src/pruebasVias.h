/*
 * pruebasVias.h
 *
 *  Created on: 25 mar. 2019
 *      Author: ruben
 */

#ifndef PRUEBASVIAS_H_
#define PRUEBASVIAS_H_
#include "Via.h"


/*

  - Contrucción de una via por constructor por defecto
  - introducimos sus parametros por los metodos set
  - comprobamos que todos los parametros introducidos son correctos
    con los metodos get
  - la via es mostrada al final para posterior comprobación

*/
void pruebaVias();


#endif /* PRUEBASVIAS_H_ */
