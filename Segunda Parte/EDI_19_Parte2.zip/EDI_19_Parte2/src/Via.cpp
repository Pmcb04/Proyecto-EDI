/*
 * Via.cpp
 *
 *  Created on: 25 feb. 2019
 *      Authors:  - Pedro Miguel Carmona Broncano
 									- Ruben Marin Lucas
 */

#include "Via.h"

Via::Via() {

	codigoBarrio = 0;
	codigoVia = 0;
	longitudVia = 0.0;
	nombreVia = "";

}

Via::Via(int codigoBarrio, string nombreVia,float longitudVia,string tipoVia, int codigoVia) {

	this->codigoBarrio = codigoBarrio;
	this->nombreVia = nombreVia;
	this->codigoVia = codigoVia;
	this->longitudVia = longitudVia;
	this->tipoVia = tipoVia;
}

Via::~Via() {
}

void Via::setCodigoBarrio(int codigoBarrio) {

	this->codigoBarrio = codigoBarrio;
}

void Via::setCodigoVia(int codigoVia) {

	this->codigoVia = codigoVia;
}

void Via::setLongitudVia(float longitudVia) {

	this->longitudVia = longitudVia;
}

void Via::setNombreVia(string nombreVia) {

	this->nombreVia = nombreVia;
}

void Via::setTipoVia(string tipoVia) {

	this->tipoVia = tipoVia;
}

int Via::getCodigoBarrio() {

	return codigoBarrio;
}

int Via::getCodigoVia() {

	return codigoVia;
}

float Via::getLongitudVia() {

	return longitudVia;
}

string Via::getNombreVia() {

	return nombreVia;

}

string Via::getTipoVia() {

	return tipoVia;
}

string Via::getClave() {

	string claveBarrio, claveVia, clave;
	string cero = "0";

	if(codigoBarrio < 10){

		claveBarrio = cero + to_string(codigoBarrio);

	}else{

		claveBarrio = to_string(codigoBarrio);
	}

	claveVia = to_string(codigoVia);

	for (int i = 0; i < (4-claveVia.length()); i++) {

			claveVia = cero + claveVia;

	}

	clave = claveBarrio + claveVia;

	return clave;



}

void Via:: mostrar(){


	cout << endl;
	cout << "--------Via: " << nombreVia << ": ----------" << endl << endl;
	cout << "Tipo Via: " << tipoVia << endl;
	cout << "Longitud Via: " << longitudVia << endl;
	cout << "Codigo Via: " << codigoVia << endl;
	cout << "Codigo Barrio: " << codigoBarrio << endl;
	cout << endl;


}
