/*
 * pruebasSetVias.h
 *
 *  Created on: 25 mar. 2019
 *      Author: ruben
 */

#ifndef PRUEBASETVIAS_H_
#define PRUEBASETVIAS_H_
#include "SetVias.h"



/*

1º Se construye el conjunto de vias, ademas de 3 vias que se insertarán en este.


2º Se hace comprobaciones como:

     - Que el conjunto no este vacio despues de insertar
     - que el conjunto no esté lleno antes de insertar
     - que el nº de elementos no sea distinto de 3 en nuestro caso
     - comprobacion de los nombres de los 3 vias
     - se comprueba que dichas vias se han insertado siguiendo el codigo de via
     - eliminacion de una via y comprobacion de que no existe en el conjunto despues del borrado
     - eliminacion de todas las vias restantes y comprobación de que el conjunto está vacio de nuevo

*/

void pruebaSetVias();


#endif /* PRUEBASETVIAS_H_ */
