/*
 * Algoritmos.cpp
 *
 *  Created on: 02/03/2019
 *      Author: Profesores de EDI
 */

#include <fstream>
#include <iostream>

#include "algoritmos.h"
#include "pruebas.h"


using namespace std;

// MAIN function
int main () {
    Algoritmos Algoritmos;
}


// ******************** PRIVATE OPERATIONS ********************

void Algoritmos::ficheroVias(string nombreBarrio){

        Barrio *b;
        cjtoBarrios->get(nombreBarrio, b);

        b->ficheroVias();

}

void Algoritmos::barriosMaxMin(Barrio *&mayorBarrio, Barrio *&menorBarrio){


    Barrio *b;

    int mayor = 0;
    int menor;

    for (int i = 0; i < cjtoBarrios->numElementos(); i++){

        cjtoBarrios->get(i, b);

        if(!b->estaVacio()){

            if (b->getNumElementosVias() > mayor){

                    mayorBarrio = b;
                    mayor = b->getNumElementosVias();

            }

            if (b->getNumElementosVias() < menor){

                    menorBarrio = b;
                    menor = b->getNumElementosVias();

            }



        }

    }

    menor = mayor;

    for (int i = 0; i < cjtoBarrios->numElementos(); i++){

        cjtoBarrios->get(i, b);

        if(!b->estaVacio()){

            if (b->getNumElementosVias() < menor){

                    menorBarrio = b;
                    menor = b->getNumElementosVias();

            }



        }

    }

}


void Algoritmos::barrioSubcadena(string subcadena){

    Barrio *b;

    for (int i = 0; i < cjtoBarrios->numElementos(); i++){

        cjtoBarrios->get(i, b);

            if(b->getNombre().find(subcadena) == 0){

              cout << "Nombre del Barrio: " << b->getNombre() << endl;
              cout << "Vias pertenecientes a este Barrio que empiecen por la subcadena: " << endl;

              SetVias *conjuntoVias;
              Via *v;

          for (int k = 0; k < conjuntoVias->numElementos(); k++) {
            /* code */
                  conjuntoVias->get(k, v);

                  if(v->getNombreVia().find(subcadena) == 0){

                      cout << v->getNombreVia() << endl;

                  }
          }

          cout << endl << endl;

      }
  }
}

void Algoritmos::mayorAvenida(Via *&avda, string &distrito){

    Barrio *b;
    Via *aux = new Via();

    for (int i = 0; i < cjtoBarrios->numElementos(); i++){

        cjtoBarrios->get(i, b);

        if(!b->estaVacio()){

            b->MaxAvenida(aux);

            if(aux->getLongitudVia() > avda->getLongitudVia()){

                avda = aux;
                distrito = b->getDistrito();

            }
        }

    }


}

void Algoritmos::run() {

  Via *avda = new Via();
  string distrito, subcadena, nombreBarrio;
  bool enc = false;

  Barrio *mayorBarrio = NULL;
  Barrio *menorBarrio = NULL;



// Algoritmo 0 (ejemplo)
	mostrarBarrios();


while(!enc){

    cout << "Introduce el nombre de un barrio: "  << endl;
    getline(cin, nombreBarrio);

    if(cjtoBarrios->existeBarrio(nombreBarrio)){

        enc = true;

    }else{

      cout << "El nombre introducido no corresponde a ningun barrio." << endl;

    }

}

// Algoritmo 1
 ficheroVias(nombreBarrio);



 // Algoritmo 2
  barriosMaxMin(mayorBarrio, menorBarrio);

  cout << "--------------- Barrio con mayor nº de calles (" << menorBarrio->getNumElementosVias() << "):--------------" << endl;
  menorBarrio->mostrar();

  cout << "--------------- Barrio con mayor nº de calles (" << mayorBarrio->getNumElementosVias() << "):--------------" << endl;
  mayorBarrio->mostrar();



  // Algoritmo 3
  cout << "Introduce subcadena: "  << endl;
  getline(cin, subcadena);
  cout << endl;
  barrioSubcadena(subcadena);


  // Algoritmo 4
  mayorAvenida(avda, distrito);
  cout << "La via de mayor longitud de Cáceres es: " << endl << endl;
  avda->mostrar();
  cout << "El distrito al que pertenece es: " << distrito << endl;
  delete avda;



  //pruebas
 pruebas(cjtoBarrios);


}

void Algoritmos::cargarDatos() {

    Barrio *b;
    Via *v;

    IList <Via*> *listaVias;

    string linea;
    string campo[5];

    fstream flujoBarrio;
    flujoBarrio.open("Barrio.csv");

    fstream flujoVias;
    flujoVias.open("Via.csv");

    fstream flujoArboles;
    flujoArboles.open("Arbol.csv");



    if(!flujoBarrio.eof()){

        getline(flujoBarrio, linea);

        while(!flujoBarrio.eof()){

            for (int i = 0; i < 4; i++){

                getline(flujoBarrio, campo[i], ';');
            }

            getline(flujoBarrio, campo[4]);

            if (!flujoBarrio.eof()){

                b = new Barrio(campo[0], atof(campo[1].c_str()), atof(campo[2].c_str()),  atoi(campo[3].c_str()), campo[4]);
                cjtoBarrios->insertar(b);
            }

        }
        flujoBarrio.close();
    }

    if(!flujoVias.eof()){

        getline(flujoVias, linea);

        while(!flujoVias.eof()){

            for (int i = 0; i < 4; i++){

                getline(flujoVias, campo[i], ';');
            }

            getline(flujoVias, campo[4]);

            if (!flujoVias.eof()){

                v = new Barrio(campo[0], atof(campo[1].c_str()), atof(campo[2].c_str()),  atoi(campo[3].c_str()), campo[4]);
                listaVias->insertar(v);
            }

        }
        flujoVias.close();
    }


    if(!flujoArboles.eof()){

        getline(flujoArboles, linea);

        while(!flujoArboles.eof()){

            for (int i = 0; i < 4; i++){

                getline(flujoArboles, campo[i], ';');
            }

            getline(flujoArboles, campo[4]);

            if (!flujoArboles.eof()){

                b = new Barrio(campo[0], atof(campo[1].c_str()), atof(campo[2].c_str()),  atoi(campo[3].c_str()), campo[4]);

            }

        }
        flujoArboles.close();
    }


}


// ******************** PUBLIC INTERFACE ********************


Algoritmos::Algoritmos() {

    cout << "Programming Project v1.00 (EDI)." << endl;
    cout << "           Author: xx xx xx." << endl;
    cout << "           Date:   March 8th, 2019." << endl;



    cjtoBarrios = new SetBarrios();
    this->cargarDatos();
    this->run();
}


void Algoritmos::mostrarBarrios(){


    for (int i = 0; i < cjtoBarrios->numElementos(); i++){

        cjtoBarrios->mostrar();

    }
}

void Algoritmos::insertar(Via *v){

		Via *aux;
		bool enc = false;
		bool rep = false;

		lVias->moverInicio();

		while(!lVias->finLista() && !enc && !rep){

			lVias->consultar(aux);

			if( aux->getNombreVia() > v->getNombreVia() ){

			 enc = true;

		 }else if(aux->getCodigoVia() == v->getCodigoVia()){

					rep = true;

			}else{

				lVias->avanzar();

			}

		}

		if(!rep){

				lVias->insertar(v);

		}

}


Algoritmos::~Algoritmos(){

    delete cjtoBarrios;
}
