/*
 * pruebasSetVias.cpp
 *
 *  Created on: 25 mar. 2019
 *      Author: ruben
 */

#include "pruebaSetVias.h"

void pruebaSetVias(){
	SetVias *cjtoVias;
	Via *v1;
	Via *v2;
	Via *v3;
	Via *vaux;

	v1 = new Via();
	v2 = new Via();
	v3 = new Via();
	cjtoVias = new SetVias();

	cout << "-------------INICIO PRUEBA SETVIA--------------" << endl;

	if(!cjtoVias->estaVacia()){
		cout <<"ERROR: El conjunto de vias no esta vacio" <<endl;
	}

	v1->setCodigoVia(70);
	v2->setCodigoVia(3);
	v3->setCodigoVia(55);

	cjtoVias->insertar(v1);
	cjtoVias->insertar(v2);
	cjtoVias->insertar(v3);

	if(cjtoVias->estaVacia()){
		cout <<"ERROR: El conjunto de vias esta vacio"<<endl;
	}
	if(cjtoVias->numElementos() != 3){
		cout<<"ERROR: El número de vias no es correcto"<<endl;
	}

	if(!cjtoVias->existe(70)){
		cout<< "ERROR: No existe via con codigo 70"<<endl;
	}
	if(!cjtoVias->existe(3)){
		cout<< "ERROR: No existe via con codigo 3"<<endl;
	}
	if(!cjtoVias->existe(55)){
		cout<< "ERROR: No existe via con codigo 55"<<endl;
	}

	cjtoVias->get(0,vaux);
	if(vaux->getCodigoVia()!= v2->getCodigoVia()){
		cout << "ERROR: Primera via" <<endl;
	}
	cjtoVias->get(2,vaux);
	if(vaux->getCodigoVia()!= v1->getCodigoVia()){
		cout<<"ERROR: Tercera via" <<endl;
	}

	cjtoVias->eliminar(70);

	if(cjtoVias->existe(70)){
		cout<< "ERROR: No puede existir via con codigo 70"<<endl;
	}

	cjtoVias->eliminar(3);
	cjtoVias->eliminar(55);

	if(!cjtoVias->estaVacia()){
		cout <<"ERROR: El conjunto de vias no esta vacio"<<endl;
	}

cout <<"----------------FIN PRUEBA SETVIAS--------------"<<endl;

	delete v1;
	delete v2;
	delete v3;
	delete cjtoVias;


}
