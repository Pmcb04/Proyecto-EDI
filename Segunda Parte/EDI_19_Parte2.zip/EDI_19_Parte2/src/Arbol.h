/*
 * Arbol.h
 *
 *  Created on: 18 feb. 2019
 *      Authors:  - Pedro Miguel Carmona Broncano
 									- Ruben Marin Lucas
 */



#ifndef ARBOL_H_
#define ARBOL_H_

#include <string>
#include <iostream>
using namespace std;

class Arbol {

  string especie;
  string familia;
  string nombreComun;
  string genero;
  string riego;
  float diametro;
  float altura;
  float copa;
  int unidades;
  int codigoVia;

public:

  Arbol();
  Arbol(const Arbol &a);

  void setEspecie(string especie);
  void setFamilia(string familia);
  void setNombreComun(string nombreComun);
  void setGenero(string genero);
  void setRiego(string riego);
  void setDiametro(float diametro);
  void setAltura(float altura);
  void setCopa(float copa);
  void setUnidades(int unidades);
  void setCodigoVia(int codigoVia);


  string getEspecie();
  string getFamilia();
  string getNombreComun();
  string getGenero();
  string getRiego();
  float getDiametro();
  float getAltura();
  float getCopa();
  int getUnidades();
  int getCodigoVia();

};

#endif /* ARBOL_H_ */
