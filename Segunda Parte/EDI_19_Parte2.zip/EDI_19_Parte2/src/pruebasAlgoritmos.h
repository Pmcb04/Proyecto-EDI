
#ifndef PRUEBASALGORITMOS_H_
#define PRUEBASALGORITMOS_H_

#include <fstream>
#include <iostream>
#include "algoritmos.h"
using namespace std;

//EXPLICACION

/*
 * PRE: { -cjtoBarrios- debe estar inicializado}
 * POST:{ comprueba si el fichero generado con anterioridad es correcto}
 * COMPLEJIDAD:O(n)
 */
void pruebaFicheroVias(SetBarrios *&cjtoBarrios);

  /*
  Para el resto de pruebas hemos creado un nuevo fichero PruebaBarrio.csv
  en el que hemos introducido 5 barrios.

  No se ha utilizado en el desarrollo, pero si durante este se a consultado al fichero PruebaVia.csv
  para ver que los resultados obtenidos son correctos.

  Así tendremos una situación controlada en la que sabremos cual es el resultado que queremos
  para nuestros algoritmos:

  Primero lo que haremos será cargar los datos de estos nuevos ficheros, para ello usaremos
  un algoritmo idéntico a cargarDatos pero cambiando el nombre del fichero:
  */


/*
 * PRE: { -conjuntoPruebas- debe estar inicializado}
 * POST:{ carga en -conjuntoPruebas- los barrios del fichero "PruebaBarrio.csv"}
 * COMPLEJIDAD:O(n)
 */
void cargarFicherosPrueba(SetBarrios *&conjuntoPruebas);


/*
Para probar el funcionamiento del Algoritmo 2 (BarriosMaxMin) hemos copiado el codigo de dicho algoritmo.

   El resultado esperado:                                                     Puesto que al ejecutar no se muestra ningun mensaje de error el resultado obtenido:
   Barrio con mayor numero de vias -> Cabezarrubia (15 vias)                  Barrio con mayor numero de vias -> Cabezarrubia
   Barrio con menor numero de vias -> Poligono Ganadero (0 vias)              Barrio con menor numero de vias -> Poligono ganadero

*/

/*
 * PRE: { -conjuntoPruebas- debe estar inicializado}
 * POST:{ comprueba que los barrios con menor y mayor nº de calles son los esperados}
 * COMPLEJIDAD:O(n)
 */
void pruebaBarriosMaxMin(SetBarrios *&conjuntoPruebas);


/*
Para probar el funcionamiento del Algoritmo 3 (BarrioSubcadena) hemos copiado el codigo de dicho algoritmo.

  Puesto que el ejecutar no muestra ningun fallo, el algoritmo funciona adecuadamente.

*/

/*
 * PRE: { -conjuntoPruebas- debe estar inicializado}
 * POST:{ comprueba que la subcadena introducida realiza su funcion }
 * COMPLEJIDAD:O(n)
 */
void pruebaBarrioSubcadena(SetBarrios *&conjuntoPruebas);



/*
Para probar el funcionamiento del Algoritmo 2 (BarriosMaxMin) hemos copiado el codigo de dicho algoritmo.

   El resultado esperado:                                                     Puesto que al ejecutar no se muestra ningun mensaje de error el resultado obtenido:
   La via de mayor longitud -> De las Arenas                                    La via de mayor longitud -> De las Arenas
   El distrito al que pertenece la via de mayor longitud -> oeste               El distrito al que pertenece la via de mayor longitud -> oeste
   Barrio con la via de mayor longitud -> El vivero ó Cabezarrubia              Barrio con la via de mayor longitud -> El vivero ó Cabezarrubia

*/

/*
 * PRE: { -conjuntoPruebas- debe estar inicializado}
 * POST:{ comprueba que la mayor Avda es la esperada }
 * COMPLEJIDAD:O(n)
 */
void pruebaMayorAvenida(SetBarrios *&conjuntoPruebas);

/*
 * PRE: { -conjuntoPruebas- debe estar inicializado}
 * POST:{  Llama a todos los algoritmos anteriores. }
 * COMPLEJIDAD:O(n)
 */
void pruebasAlgoritmos(SetBarrios *&cjtoBarrios);


#endif /* PRUEBASALGORITMOS_H_ */
