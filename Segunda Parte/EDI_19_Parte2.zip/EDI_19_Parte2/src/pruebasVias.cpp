/*
 * PruebasVias.cpp
 *
 *  Created on: 25 mar. 2019
 *      Author: ruben
 */

#include "pruebasVias.h"


void pruebaVias(){
  Via *v;
  v = new Via();

  v->setNombreVia("Virgen de la Montaña");
  v->setLongitudVia(1237.98);
  v->setCodigoVia(15);
  v->setCodigoBarrio(30);
  v->setTipoVia("Calle");

cout << "-------------INICIO PRUEBAS VIAS-------------" <<endl;

   if(v->getCodigoBarrio() != 30){
     cout << "ERROR: en CodigoBarrio " <<endl;
   }
   if(v->getCodigoVia() != 15 ){
     cout <<"ERROR: en CodigoVia " <<endl;
   }
   if(v->getTipoVia() != "Calle"){
     cout << "ERROR: en TipoVia"<<endl;
   }
   if(v->getNombreVia() != "Virgen de la Montaña"){
     cout << "ERROR: en NombreVia"<<endl;
   }

   cout<<"-----------------FIN PRUEBAS VIAS-----------------"<<endl;

   v->mostrar();

   delete v;

}
