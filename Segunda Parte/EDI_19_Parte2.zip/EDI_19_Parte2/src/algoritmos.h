/*
 * Algoritmos.h
 *
 *  Created on: 02/03/2019
 *      Author: Profesores de EDI
 */

#ifndef ALGORITMOS_H_
#define ALGORITMOS_H_

#include "SetBarrios.h"
#include "SetVias.h"

class Algoritmos {

private:

	SetBarrios *cjtoBarrios;

	/*
	 * PRE: { Fichero "Barrio.csv" creado correctamente}
	 * POST:{ carga los datos desde los ficheros de texto "Barrio.h" }
	 * COMPLEJIDAD:O(n²)
	 */
	void cargarDatos();

	/*
	 * PRE: { Los modulos que son llamados deben estar declarados }
	 * POST:{ ejecuta todos los algoritmos del proyecto }
	 * COMPLEJIDAD:O(n)
	 */

	void run ();

public:

	/*
	 * PRE: {  }
	 * POST:{ Crea el objeto algoritmo }
	 * COMPLEJIDAD:O(1)
	 */
	 Algoritmos();

		// Algoritmo 0 (ejemplo)

	 /*
		* PRE: {  }
		* POST:{ muestra todos los barrios con sus vías }
		* COMPLEJIDAD:O(n)
		*/
	 void mostrarBarrios();

   //Algoritmo 1

	 /*
	  * PRE: { -cjtoBarrios- declarado con anterioridad y con los barrios incluidos }
	  * POST:{ Pide un barrio por teclado y escribe en el fichero "ficheroVias.csv"
	 					 las calles pertenecientes a ese barrio, si no tiene calles, se muestra
					 		un mensaje en ese archivo indicandolo.}
	  * COMPLEJIDAD:O(n)
	  */
   void ficheroVias(string nombreBarrio);

   // Algoritmo 2

	 /*
	 * PRE: { -cjtoBarrios- declarado con anterioridad y con los barrios incluidos }
	 * POST:{	Devuelve por pantalla los barrios con un menor y un mayor numero de calles
	 					pertenecientes a ese barrio }
	 * COMPLEJIDAD:O(n)
	 */
	 void barriosMaxMin(Barrio *&mayorBarrio, Barrio *&menorBarrio);

	 //Algoritmo 3

	 /*
	 * PRE: { -cjtoBarrios- declarado con anterioridad y con los barrios incluidos }
	 * POST:{ Pide una subcadena por teclado, y una vez introducida devuelve el/los barrio/s cuyo nombre comienza por esa subcadena,
   *        si no existe ningún barrio que comience por esa subcadena muestra un mensaje de ERROR}
	 * COMPLEJIDAD:O(n²)
	 */
	 void barrioSubcadena(string subcadena);

	 //Algortimo 4

	 /*
	 * PRE: { -cjtoBarrios- declarado con anterioridad y con los barrios incluidos }
	 * POST:{ Devuelve por pantalla la mayor avenida de todos los barrios, así como el ditrito al
	 					que pertenece y el barrio al que pertenece, así como la longitud de la Avda}
	 * COMPLEJIDAD:O(n²)
	 */
	 void mayorAvenida(Via *&avda, string &distrito);

	 /*
	 * PRE: { -cjtoBarrios- declarado con anterioridad y con los barrios incluidos }
	 * POST:{ Destruye -cjtobarrios- }
	 * COMPLEJIDAD:O(1)
	 */
	 ~Algoritmos();

};

#endif /* ALGORITMOS_H_ */
