/*
 * pruebaSetBarrios.cpp
 *
 *  Created on: 25 mar. 2019
 *      Author: ruben
 */

#include "pruebaSetBarrios.h"

void pruebaSetBarrios(){
	SetBarrios *cjtoBarrios;
	Barrio *b1;
	Barrio *b2;
	Barrio *b3;
	Barrio *baux;

		b1 = new Barrio();
		b2 = new Barrio();
		b3 = new Barrio();
		cjtoBarrios = new SetBarrios();

		cout << "-------------INICIO PRUEBA SETBARRIOS--------------" << endl;

		if(!cjtoBarrios->estaVacia()){
			cout <<"ERROR: El conjunto de vias no esta vacio" <<endl;
		}

	
		b1->setNombre("El Vivero");
		b2->setNombre("Campus Universitario");
		b3->setNombre("La Cañada");

		cjtoBarrios->insertarBarrios(b1);
		cjtoBarrios->insertarBarrios(b2);
		cjtoBarrios->insertarBarrios(b3);

		if(cjtoBarrios->estaVacia()){
			cout <<"ERROR: El conjunto de barrios esta vacio"<<endl;
		}
		if(cjtoBarrios->numElementos() != 3){
			cout<<"ERROR: El número de barrios no es correcto"<<endl;
		}

		if(!cjtoBarrios->existeBarrio("El Vivero")){
			cout<< "ERROR: No existe barrio con nombre El Vivero"<<endl;
		}
		if(!cjtoBarrios->existeBarrio("Campus Universitario")){
			cout<< "ERROR: No existe barrio con nombre Campus Universitario"<<endl;
		}
		if(!cjtoBarrios->existeBarrio("La Cañada")){
			cout<< "ERROR: No existe barrio con nombre La Cañada"<<endl;
		}

		cjtoBarrios->get(0,baux);
		if(baux->getNombre()!= b2->getNombre()){
			cout << "ERROR: Primer barrio" <<endl;
		}
		cjtoBarrios->get(2,baux);
		if(baux->getNombre()!= b3->getNombre()){
			cout<<"ERROR: Tercer barrio" <<endl;
		}

		cjtoBarrios->eliminar("El Vivero");

		if(cjtoBarrios->existeBarrio("El Vivero")){
			cout<< "ERROR: No puede existir un barrio con nombre El Vivero"<<endl;
		}

		cjtoBarrios->eliminar("Campus Universitario");
		cjtoBarrios->eliminar("La Cañada");

		if(!cjtoBarrios->estaVacia()){
			cout <<"ERROR: El conjunto de vias no esta vacio"<<endl;
		}

	cout <<"----------------FIN PRUEBA SETBARRIOS--------------"<<endl;

		delete b1;
		delete b2;
		delete b3;
		delete cjtoBarrios;

}
