/*
 * pruebasBarrios.h
 *
 *  Created on: 25 mar. 2019
 *      Author: ruben
 */

#ifndef PRUEBASBARRIOS_H_
#define PRUEBASBARRIOS_H_

#include "Barrio.h"

//lamada a todos los modulos de prueba de este fichero
void pruebasBarrios();

/*Se construye un barrio mediante constructor parametrizado
y se comprueba que los datos introducidos son correctos ademas
 de imprimir la información de ese barrio para posterior
 comprobación*/
void pruebasBarrios1();


/*
  Comprueba algunos metodos de barrio.cpp que no son tan basicos
   con los constructores y que se utiliza para la clase algoritmo.
*/
void pruebasBarrios2();

#endif /* PRUEBASBARRIOS_H_ *///set y get, y ademas hay que hacer algo con setvias
