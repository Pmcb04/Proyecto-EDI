/*
 * pruebasBarrios.cpp
 *
 *  Created on: 25 mar. 2019
 *      Author: ruben
 */
#include "pruebasBarrios.h"
void pruebasBarrios1(){

	Barrio *b;

	b = new Barrio("La Cañada",109035.09,1782.1,77,"sur");



	if(b->getCodigo() != 77){
		cout << "ERROR: en codigo de barrio"<<endl;
	}
	if(b->getNombre() != "La Cañada"){
		cout << "ERROR: en nombre de barrio"<<endl;
	}
    if(b->getDistrito() != "sur"){
    	cout << "ERROR: en distrito"<<endl;
    }
    if(b->estaVacio()){
    	cout << "ERROR: este barrio no tiene vias"<<endl;
    }


    b->mostrar();


	delete b;


}

void pruebasBarrios2(){
	Barrio *b;
	Via *vaux;

	b = new Barrio("Cabezarrubia",258626.62,2217.97,30,"oeste");

    if(!(b->buscarVia("Pisa", vaux))){
    	cout<<"ERROR: Via no encontrada"<<endl;
    }

    b->MaxAvenida(vaux);
    if(vaux->getCodigoVia() != 4143){
    	cout<<"ERROR: No es la avenida maxima"<<endl;
    }


    delete b;

}

void pruebasBarrios(){


cout << "-------------INICIO PRUEBA BARRIOS--------------" << endl;

	pruebasBarrios1();
	pruebasBarrios2();


	cout << "-------------FIN PRUEBA BARRIOS--------------" << endl;

}
