/*
 * setVias.cpp
 *
 *  Created on: 4 mar. 2019
 *      Author: pedro
 */

#include "SetVias.h"

#include <iostream>
using namespace std;

SetVias::SetVias() {

	cont = 0;

}

SetVias::~SetVias() {


	for (int i = 0; i < cont; i++) {

			delete setVias[i];

		}


}


bool SetVias::estaVacia() {

	return cont == 0;

}

int SetVias::numElementos() {

	return cont;

}

void SetVias::insertar(Via* v) {

		int i = 0;
		bool enc = false;

		while (i < cont && !enc){

			if(setVias[i]->getCodigoVia() > v->getCodigoVia()){

				enc = true;

			}else{

				i++;

			}

		}


		if(enc){

			for (int j = cont; j > i; j--) {

				setVias[j] = setVias[j-1];

			}

		}

		setVias[i] = v;
		cont++;

}

bool SetVias::existe(int codigoVia) {

	bool existe = false;
	int i = 0;

	while(i < cont && !existe){

		if(setVias[i]->getCodigoVia() == codigoVia){

			existe = true;
		}

		i++;
	}

	return existe;

}

void SetVias::get(int pos, Via*& v) {

	v = setVias[pos];
}

void SetVias::getCodigo(int codigoVia, Via*&v) {

	bool enc = false;
	int i = 0;

	while(i < cont && !enc){

		if(setVias[i]->getCodigoVia() == v->getCodigoVia()){

			v = setVias[i];
			enc = true;
		}

		i++;
	}

}

void SetVias::eliminar(int codigoVia) {


	int i = 0;
	bool enc = false;

	while(i < cont && !enc){

		if(setVias[i]->getCodigoVia() == codigoVia){

			enc = true;

		}else{

			i++;

		}

	}

	if(enc){

		for (int j = i; j < cont ; j++){

			setVias[j] = setVias[j+1];

	}

		cont--;

	}

}

void SetVias::mostrar() {

		for (int i = 0; i < cont; i++) {

			setVias[i]->mostrar();

		}

}
