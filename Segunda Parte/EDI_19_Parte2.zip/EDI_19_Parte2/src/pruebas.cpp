
#include "pruebas.h"


void pruebas(SetBarrios *&cjtoBarrios){

  pruebaVias();
  pruebaSetVias();
  pruebasBarrios();
  pruebaSetBarrios();
  pruebasAlgoritmos(cjtoBarrios);

}
