/*
 * Barrio.cpp
 *
 *  Created on: 18 feb. 2019
 *      Authors:  - Pedro Miguel Carmona Broncano
 									- Ruben Marin Lucas
 */

#include "Barrio.h"
#include <fstream>

Barrio::Barrio() {

	nombre = "";
	nombreDistrito = "";
	area = 0.0;
	perimetro = 0.0;
	codigo = 0;
	conjuntoVias = NULL;
}

Barrio::Barrio(string nombre, float area, float perimetro, int codigo, string distrito) {

	this->nombre = nombre;
	this->area = area;
	this->perimetro = perimetro;
	this->codigo = codigo;
	this->nombreDistrito = distrito;
	conjuntoVias = NULL;
}

Barrio::~Barrio() {

	if(conjuntoVias != NULL){

		delete conjuntoVias;

	}

}

void Barrio::setNombre(string nombre) {

	this->nombre = nombre;
}

void Barrio::setArea(float area) {

	this->area = area;

}

void Barrio::setPerimetro(float perimetro) {

	this->perimetro = perimetro;

}

void Barrio::setDistrito(string distrito) {

	this->nombreDistrito = distrito;

}

void Barrio::setCodigo(int codigo){

	this->codigo = codigo;

}

void Barrio::mostrar(){

	cout << "--------Barrio " << nombre << ": ----------" << endl << endl;

	cout << "Area del barrio: " << area << endl;
	cout << "Perimetro del barrio: " << perimetro << endl;
	cout << "Distrito del barrio: " << nombreDistrito << endl;
	cout << "Codigo del barrio: " << codigo << endl;
	cout << endl;

	cout << "--------Calles del barrio " <<this->getNombre() << ": ----------" << endl << endl;

		if(!this->estaVacio()){

					conjuntoVias->mostrar();

		}else{

			cout << "No hay calles asociadas a este barrio" << endl << endl;

		}


}

string Barrio::getNombre() {

	return nombre;
}

void Barrio::getNombre(string& nombre) {

	nombre = this->nombre;

}

float Barrio::getArea() {

	return area;

}

float Barrio::getPerimetro() {

	return perimetro;
}

int Barrio::getCodigo() {

	return codigo;
}

string Barrio::getDistrito() {

	return nombreDistrito;
}

void Barrio::insertarVia(Via *via){

	if(conjuntoVias == NULL){

		conjuntoVias = new SetVias();

	}

	conjuntoVias->insertar(via);

}

void Barrio::cargarVias() {

	Via *v;
	string linea;
	string campo[5];

	fstream flujoEntrada;
	flujoEntrada.open("Via.csv");

	if(!flujoEntrada.eof()){

		getline(flujoEntrada, linea);

		while(!flujoEntrada.eof()){

			for (int i = 0; i < 4; i++){

				getline(flujoEntrada, campo[i], ';');
			}

			getline(flujoEntrada, campo[4]);

			if (!flujoEntrada.eof() && (atoi(campo[0].c_str())) == codigo){

				v = new Via (atoi(campo[0].c_str()), campo[1], atof(campo[2].c_str()), campo[3], atoi(campo[4].c_str()));
				insertarVia(v);

			}

		}

		flujoEntrada.close();

	}

}

float Barrio::longitudTotalVias(){

	Via *v;
	float lenght = 0;

	for (int i = 0; i < conjuntoVias->numElementos(); i++){

		conjuntoVias->get(i, v);
		lenght = lenght + v->getLongitudVia();

	}

	return lenght;

}

bool Barrio::buscarVia(string nombreVia, Via *&v){

	int i = 0;
	int enc = false;

	while (i < conjuntoVias->numElementos() && !enc){

		conjuntoVias->get(i, v);

		if(nombreVia == v->getNombreVia()){

			enc = true;

		}

		i++;

	}

	return enc;

}

bool Barrio::estaVacio(){

	bool bandera = true;

	if(conjuntoVias != NULL){

		bandera = false;

	}

	return bandera;

}

int Barrio::getNumElementosVias(){

	return conjuntoVias->numElementos();

}

void Barrio::ficheroVias(){

	ofstream flujoSalida;
	flujoSalida.open("ficheroVias.txt");

	if(!flujoSalida.fail()){

		        if(!this->estaVacio()){

					flujoSalida << "-------------- Calles pertenecientes al barrio " << "%" << nombre << "%" << " ------------------------" <<  endl;

					Via *v;

					for (int i = 0; i < conjuntoVias->numElementos(); i++){

						conjuntoVias->get(i, v);
						flujoSalida << v->getNombreVia() << endl;

					}

		        }else{

		            flujoSalida << "No hay calles que pertenezcan al barrio " << nombre << endl;

		        }

	}

	    flujoSalida.close();
}

void Barrio::MaxAvenida(Via *&v){

	Via *aux;

	for (int i = 0; i < conjuntoVias->numElementos(); ++i){

		conjuntoVias->get(i, aux);

		if(aux->getTipoVia() == "Avda" && aux->getLongitudVia() > v->getLongitudVia()){

			v = aux;

		}

	}


}
