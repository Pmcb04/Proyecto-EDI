
#include "pruebasAlgoritmos.h"

void pruebaFicheroVias(SetBarrios *&cjtoBarrios){

  cout << "--------------- INICIO PRUEBA FICHERO VIAS ---------------" << endl;

  fstream prueba;
  prueba.open("ficheroVias.txt");

  string basura1, basura2, barrio, via;
  Barrio *b;
  Via *v;

  if(!prueba.eof()){

    getline(prueba, basura1, '%');
    getline(prueba, barrio, '%');
    getline(prueba, basura2);

  if(cjtoBarrios->existeBarrio(barrio)){

    while(!prueba.eof()){

      cjtoBarrios->get(barrio, b);
      getline(prueba, via);

      if(!b->buscarVia(via, v) && !prueba.eof()){

        cout << "ERROR Via " + via + " not found" << endl;

      }

    }

  }else{

    cout << "ERROR Barrio " + barrio + " not found" << endl;

  }

    prueba.close();

  }

  cout << "--------------- FIN PRUEBA FICHERO VIAS ---------------" << endl;



}

void cargarFicherosPrueba(SetBarrios *&conjuntoPruebas){


  Barrio *b;
  string linea;
  string campo[5];

  fstream flujoEntrada;
  flujoEntrada.open("PruebaBarrio.csv");

  if(!flujoEntrada.eof()){

      getline(flujoEntrada, linea);

      while(!flujoEntrada.eof()){

          for (int i = 0; i < 4; i++){

              getline(flujoEntrada, campo[i], ';');
          }

          getline(flujoEntrada, campo[4]);

              b = new Barrio(campo[0], atof(campo[1].c_str()), atof(campo[2].c_str()),  atoi(campo[3].c_str()), campo[4]);
              conjuntoPruebas->insertarBarrios(b);

      }

      flujoEntrada.close();

  }


}

void pruebaBarriosMaxMin(SetBarrios *&conjuntoPruebas,Barrio *&mayorBarrio, Barrio *&menorBarrio ){

    cout << "--------------- INICIO PRUEBA BARRIOS MAYOR MENOR ---------------" << endl;

    Barrio *b;

    int mayor = 0;
    int menor;

    for (int i = 0; i < conjuntoPruebas->numElementos(); i++){

        conjuntoPruebas->get(i, b);

        if(!b->estaVacio()){

            if (b->getNumElementosVias() > mayor){

                    mayorBarrio = b;
                    mayor = b->getNumElementosVias();

            }

            if (b->getNumElementosVias() < menor){

                    menorBarrio = b;
                    menor = b->getNumElementosVias();

            }



        }

    }

    menor = mayor;

    for (int i = 0; i < conjuntoPruebas->numElementos(); i++){

        conjuntoPruebas->get(i, b);

        if(!b->estaVacio()){

            if (b->getNumElementosVias() < menor){

                    menorBarrio = b;
                    menor = b->getNumElementosVias();

            }



        }

    }


  if(menor != 5){

    cout << "ERROR menor nº de vias != 5" << endl;

  }

  if(mayor != 15){

    cout << "ERROR mayor nº de vias != 15" << endl;


  }


    cout << "--------------- FIN PRUEBA BARRIOS MAYOR MENOR ---------------" << endl;



}

void pruebaBarrioSubcadena(SetBarrios *&conjuntoPruebas, string subcadena){

  cout << "--------------- INICIO PRUEBA BARRIO SUBCADENA ---------------" << endl;


  Barrio *b;
  bool enc = false;

  for (int i = 0; i < conjuntoPruebas->numElementos(); i++){

      conjuntoPruebas->get(i, b);

          if(b->getNombre().find(subcadena) == 0){

            SetVias *conjuntoVias;
            Via *v;

        for (int k = 0; k < conjuntoVias->numElementos(); k++) {
          /* code */
                conjuntoVias->get(k, v);

                if(v->getNombreVia().find(subcadena) == 0){

                    cout << "ERROR hay vias que empiezan por esa subcadena" << endl;

                }
        }
    }
}
    cout << "--------------- FIN PRUEBA BARRIO SUBCADENA ---------------" << endl;

}

void pruebaMayorAvenida(SetBarrios *&conjuntoPruebas, Via *&avda, string &distrito){

  Barrio *b;
  Via *aux = new Via();

  for (int i = 0; i < conjuntoPruebas->numElementos(); i++){

      conjuntoPruebas->get(i, b);

      if(!b->estaVacio()){

          b->MaxAvenida(aux);

          if(aux->getLongitudVia() > avda->getLongitudVia()){

              avda = aux;
              distrito = b->getDistrito();

          }
      }

  }


      if(avda->getTipoVia() != "Avda"){

        cout << "ERROR la via no es de tipo Avda" << endl;

      }else if(avda->getNombreVia() != "De Las Arenas"){

        cout << "ERROR la via no es la de mayor longitud" << endl;

      }else if(distrito != "oeste"){

        cout << "ERROR el distrito no se corresponde con al barrio con la mayor Avda" << endl;

      }


    cout << "--------------- FIN PRUEBA MAYOR AVENIDA ---------------" << endl;

}

void pruebasAlgoritmos(SetBarrios *&cjtoBarrios){


  Via *avda = new Via();
  string distrito, subcadena;
  bool enc = false;

  Barrio *mayorBarrio = NULL;
  Barrio *menorBarrio = NULL;

    cout << "------------------------------ INICIO PRUEBAS ALGORITMOS------------------------------" << endl;

  pruebaFicheroVias(cjtoBarrios);

  SetBarrios *conjuntoPruebas;
  conjuntoPruebas = new SetBarrios();


  cargarFicherosPrueba(conjuntoPruebas);
  pruebaBarriosMaxMin(conjuntoPruebas, mayorBarrio, menorBarrio);

    cout << "Introduce subcadena: "  << endl;
    getline(cin, subcadena);
    cout << endl;

  pruebaBarrioSubcadena(conjuntoPruebas, subcadena);
  pruebaMayorAvenida(conjuntoPruebas, avda, distrito);


  cout << "------------------------------ FIN PRUEBAS ALGORITMOS ------------------------------" << endl;




}
