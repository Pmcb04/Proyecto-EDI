/*
 * Algoritmos.cpp
 *
 *  Created on: 02/03/2019
 *      Author: Profesores de EDI
 */

#include <fstream>
#include <iostream>
#include <time.h>
#include <iostream>
#include <string>
#include <stdio.h>
#include "algoritmos.h"
#include "pruebas.h"
using namespace std;


// MAIN function
int main () {
    Algoritmos Algoritmos;
}


// ******************** PRIVATE OPERATIONS ********************


void Algoritmos::run() {

  int opcion;
  bool salir = false;
  string pedir;
  double ini, fin, time;
  ArbolB<Via*, Comparar> *viasgenero;

do {

  cout << endl;
  cout << "Elige Opción:" << endl;
  cout << "\t 0. Algoritmo 0" << endl;
  cout << "\t 1. Algoritmo 1" << endl;
  cout << "\t 2. Algoritmo 2" << endl;
  cout << "\t 3. Algoritmo 3" << endl;
  cout << "\t 4. Algoritmo 4" << endl;
  cout << "\t 5. Pruebas" << endl;
  cout << "\t 6. Salir" << endl;

  cin >> opcion;
  cin.ignore();

  switch (opcion) {
    case 0:  //ALGORITMO 0
    mostrarDatos();
    break;

    case 1: // ALGORITMO 1

    cout << endl;
    cout << "Introduce el nombre de una via: "  << endl;
    getline(cin, pedir);
    ini = clock();
    ficheroArboles(pedir);
    fin = clock();
    time = fin - ini;
    cout << "El algoritmo 1 ha tardado: " << time/CLOCKS_PER_SEC <<  " segundos" << endl;

    break;

    case 2:  // ALGORITMO 2

    cout << endl;
    cout << "Introduce el nombre de una especie: "  << endl;
    getline(cin, pedir);
    ini = clock();
    ficheroEspecies(pedir);
    fin = clock();
    time = fin - ini;
    cout << "El algoritmo 2 ha tardado: " << time/CLOCKS_PER_SEC <<  " segundos" << endl;


    break;

    case 3:  //ALGORITMO 3

    viasgenero = new ArbolB<Via*, Comparar>;
    cout << endl;
    cout << "Introduce el nombre de un genero: "  << endl;
    getline(cin, pedir);
    ini = clock();
    SubArbol(viasgenero, pedir);
    mostrarinOrden(viasgenero);
    delete viasgenero;
    fin = clock();
    time = fin - ini;
    cout << "El algoritmo 3 ha tardado: " << time/CLOCKS_PER_SEC <<  " segundos" << endl;

    break;

    case 4:  //ALGORITMO 4

    cout << endl;
    cout << "Introduce una subCadena: "  << endl;
    getline(cin, pedir);
    ini = clock();
    ficheroSubCadena(pedir);
    fin = clock();
    time = fin - ini;
    cout << "El algoritmo 4 ha tardado: " << time/CLOCKS_PER_SEC <<  " segundos" << endl;


    break;

    case 5:  // PRUEBAS
    pruebas();
    break;

    case 6:  // SALIR
      salir = true;
    break;

    default:
      cout << "Esa opción no está diponible. Por favor marca una opción de la lista. " << endl;
    }


  } while(!salir);


}

void Algoritmos::BuscarVias(int codigoVia, Via *&v){

  Barrio *b;
  bool enc = false;

    for(int i = 0; i < cjtoBarrios->numElementos() && !enc; i++){

      cjtoBarrios->get(i, b);

       if(!b->estaVacio()){

         enc = b->buscarVia(codigoVia, v);//me devuelve la via donde insertar

       }

   }

}

void Algoritmos::mostrarinOrden(ArbolB<Via*, Comparar> *viasgenero){
  Barrio *b;
  if (!viasgenero->vacio() ){

		if (viasgenero->hijoIzq()!=NULL){
				 mostrarinOrden(viasgenero->hijoIzq());
		}

		   cout <<  viasgenero->raiz()->getNombreVia();

       for (int i = 0; i < (40 - (viasgenero->raiz()->getNombreVia().length())); i++)
         cout << ".";

       cjtoBarrios->getBarrio(viasgenero->raiz()->getCodigoBarrio(), b);
       cout << b->getNombre() <<endl;


		if (viasgenero->hijoDer()!=NULL){
				 mostrarinOrden(viasgenero->hijoDer());
		}

	}
}


void Algoritmos::cargarDatos() {

  Barrio *b;
  Via *v;
  Arbol *a;

  string linea;
  string campo[10];

  fstream flujoBarrio;
  flujoBarrio.open("Barrio.csv");

  fstream flujoVias;
  flujoVias.open("Via.csv");

  fstream flujoArboles;
  flujoArboles.open("Arbol.csv");



  if(!flujoBarrio.eof()){

      getline(flujoBarrio, linea);

      while(!flujoBarrio.eof()){

          for (int i = 0; i < 4; i++){

              getline(flujoBarrio, campo[i], ';');
          }

          getline(flujoBarrio, campo[4]);

          if (!flujoBarrio.eof()){

              b = new Barrio(campo[0], atof(campo[1].c_str()), atof(campo[2].c_str()),  atoi(campo[3].c_str()), campo[4]);
              cjtoBarrios->insertarBarrios(b);
          }

      }
      flujoBarrio.close();
  }


  if(!flujoVias.eof()){

      getline(flujoVias, linea);

      while(!flujoVias.eof()){

          for (int i = 0; i < 4; i++){

              getline(flujoVias, campo[i], ';');
          }

          getline(flujoVias, campo[4]);

          if (!flujoVias.eof()){

              v = new Via(atoi(campo[0].c_str()), campo[1], atof(campo[2].c_str()),campo[3], atoi(campo[4].c_str()));

              cjtoBarrios->getBarrio(atoi(campo[0].c_str()), b);

                b->insertarVias(v);

          }


      }
      flujoVias.close();
  }


  if(!flujoArboles.eof()){

      getline(flujoArboles, linea);

      while(!flujoArboles.eof()){

          for (int i = 0; i < 9; i++){

              getline(flujoArboles, campo[i], ';');
          }

          getline(flujoArboles, campo[9]);

          if (!flujoArboles.eof()){

              a = new Arbol(campo[0], campo[1], campo[2], campo[3], atof(campo[4].c_str()),
                            atof(campo[5].c_str()), atof(campo[6].c_str()), campo[7],
                            atoi(campo[8].c_str()), atoi(campo[9].c_str()));

            BuscarVias(atoi(campo[9].c_str()),v);

            v->insertarArboles(a);

          }

      }
      flujoArboles.close();
  }
}



// ******************** PUBLIC INTERFACE ********************


Algoritmos::Algoritmos() {

  cout << "Programming Project v3.00 (EDI)." << endl;
    cout << "           Authors: Pedro Miguel Carmona && Ruben Marín Lucas" << endl;
    cout << "           Date:   April 3th, 2019." << endl;


    cjtoBarrios = new SetBarrios();
    this->cargarDatos();
    this->run();
}

void Algoritmos::mostrarDatos(){

  if(cjtoBarrios != NULL){

  cjtoBarrios->mostrar();

  }

}

void Algoritmos::ficheroArboles(string nombreVia){ //ALGORITMO 1

  Via *v;
  Barrio *b;
  bool enc = false;
  int i = 0;

  while(!enc && i < cjtoBarrios->numElementos()){

        cjtoBarrios->get(i, b);

        if(!b->estaVacio()){
          if(b->buscarVia(nombreVia, v)){
            enc = true;
            v->ficheroArboles();
          }
        }

      i++;

  }

  if(!enc)
    cout << "No se ha podido encontrar la via introducida" << endl;

}

void Algoritmos::ficheroEspecies(string especie){ //ALGORITMO 2

  Barrio *b;
  bool enc = false;
  int total = 0;
  string nombre = "ficheroEspecies" + especie + ".txt";
  const char *datname;
  ListaPI <Nodo*> *lista = new ListaPI<Nodo*>;
  Nodo *n;
  datname = nombre.c_str();
  ofstream flujoEspecies;
  flujoEspecies.open(nombre);

   if(!flujoEspecies.fail()){

     	flujoEspecies << "-------------- Número de arboles por especie " << especie <<  " ------------------------" <<  endl;

      for(int i = 0; i < cjtoBarrios->numElementos(); i++){

        cjtoBarrios->get(i, b);

         if(!b->estaVacio())
         	b->Calles(especie, lista, enc);

      }

      if(!enc){
        remove(datname);
        cout << "No hay arboles de la especie introducida" << endl;
      }else{

        lista->moverInicio();
        while(!lista->estaVacia()){
          lista->consultar(n);
          flujoEspecies << endl;
          flujoEspecies << n->nombreVia;
          for (int i = 0; i < (40 - n->nombreVia.length()) ; i++)
            flujoEspecies << ".";
          flujoEspecies << n->arboles;
          total += n->arboles;
          delete n;
          lista->borrar();
        }
        delete lista;

        flujoEspecies << endl << "---------------------------------------------------------" << endl;
        flujoEspecies << "TOTAL ARBOLES DE LA ESPECIE " + especie + ": "  << total << endl;

        cout << "¡¡¡ " << nombre << " Creado !!!" << endl;

      }

    flujoEspecies.close();
   }
}


void Algoritmos::SubArbol(ArbolB<Via*, Comparar> *&viasgenero, string genero){ //ALGORITMO 3
  Barrio *b;

  cout << endl;
  cout << "Calles y sus barrios donde hay arboles del genero " + genero << endl;

  for(int i = 0; i < cjtoBarrios->numElementos(); i++){

     cjtoBarrios->get(i, b);

        if(!b->estaVacio())
          b->SubArbol(viasgenero, genero);
  }
}

void Algoritmos:: ficheroSubCadena(string subcadena){  // ALGORITMO 4

  string nombre = "fichero" + subcadena + ".txt";
  const char *datname;
  datname = nombre.c_str();
  Barrio *b;
  bool enc = false;

  ofstream flujoSubcadena;
  flujoSubcadena.open(nombre);

if(!flujoSubcadena.fail()){

    flujoSubcadena << "-------------- Barrios y vias que empiezan por  " << subcadena <<  " ------------------------" <<  endl;
    flujoSubcadena << endl << endl;
    flujoSubcadena << "*********************************************************************************************************" << endl;
    flujoSubcadena << "Nombre Via";
    for (int i = 0; i < 25; i++) {
      flujoSubcadena << " ";
    }
    flujoSubcadena << "Nº de Arboles";
    for (int i = 0; i < 15; i++) {
      flujoSubcadena << " ";
    }
    flujoSubcadena <<"Nombre Barrio" <<endl;

    for(int i = 0; i < cjtoBarrios->numElementos(); i++){

      cjtoBarrios->get(i, b);

       if(!b->estaVacio())
           b->subCadena(subcadena, flujoSubcadena, enc);

    }

  }

    if(!enc){
      remove(datname);
      cout << "No hay barrios que empiezen por la subCadena introducida" << endl;
    }else
      cout << "¡¡¡ " << nombre << " Creado !!!" << endl;

    flujoSubcadena << "*********************************************************************************************************" << endl;
    flujoSubcadena.close();
  }


Algoritmos::~Algoritmos() {

     delete cjtoBarrios;

}
