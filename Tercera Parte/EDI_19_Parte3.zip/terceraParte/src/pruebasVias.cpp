/*
 * pruebasVias.cpp
 *
 *  Created on: 18 feb. 2019
 *      Authors:  - Pedro Miguel Carmona Broncano
 									- Ruben Marin Lucas
 */

#include "pruebasVias.h"

const float ERROR = 0.01;

void pruebasVias(){


	cout << "-------------INICIO PRUEBA VIAS--------------------" << endl;

	pruebasPorDefectoV();
	pruebasParametrizadoV();
	pruebasSetGetV();
	pruebasInsertarArbolesV();
	pruebasNumeroArbolesV();
    pruebasEstaVacioV();
	pruebasBuscarArbolV();

	cout << "-------------FIN PRUEBA VIAS--------------------" << endl;

}


void pruebasBuscarArbolV(){

cout << "--------------- INICIO BUSCAR ARBOLES ---------------" << endl;


	Via *v1, *v2, *v3;

	Arbol *a31, *a32, *a2; // Arboles de las vias v2 y v3

	// 3464 Sophora_japonica Leguminosae SOFORA SOPHORA 0.9 7 5 NO RIEGO 1
	a2 = new Arbol ("Sophora_japonica", "Leguminosae", "SOFORA", "SOPHORA",
										0.9, 7, 5, "NO RIEGO", 1, 3464);
	// 111 Ulmus_pumila Ulmaceae OLMO DE SIBERIA ULMUS 1 7 5 NO RIEGO 1
	a31 = new Arbol ("Ulmus_pumila", "Ulmaceae", "OLMO DE SIBERIA", "ULMUS",
										1, 7, 5, "NO RIEGO", 1, 111);
	// 111 Liquidambar_styraciflua Hamamelidaceae LIQUIDAMBAR LIQUIDAMBAR 0.14 1 1 NO RIEGO 1
	a32 = new Arbol ("Liquidambar_styraciflua", "Hamamelidaceae", "LIQUIDAMBAR", "LIQUIDAMBAR",
										0.14, 1, 1, "NO RIEGO", 1, 111);

	/*********** Via Amapola **********
		346249 	Calle 	619.56*/
	v1 = new Via (49, "Amapola", 619.56, "Calle", 2568);

	/*********** Via Clavel **********
		346449 	Calle 	396.79*/
	v2 = new Via (49, "Clavel", 396.79, "Calle", 3464);

	/*********** Via Carreteros **********
		011169 	Calle 	32.79 */
	v3 = new Via (69, "Carreteros", 32.79, "Calle", 0111);


  // como no hemos insertado ningun arbol en v1, metamos el genero que
	// metamos, no debe encontrar ningun arbol

	if(!v1->estaVacia()){
		if(v1->BuscarArbol("ACER"))
				cout << "ERROR en BuscarArbol en via v1" <<endl;
	}

	// cargamos los arboles correspondientes a la via v2
	v2->insertarArboles(a2);

	// como hemos insertado solo un arbol en v2, el genero a buscar debe ser de ese arbol
	if(!v2->BuscarArbol(a2->getGenero()))
		cout << "ERROR en buscar arbol en v2 (prueba 1)" << endl;

	// ahora vamos a comprobar otro genero y vemos que no lo encuentra
	if(v2->BuscarArbol("ACER"))
		cout << "ERROR en buscar arbol en v2 (prueba 2)" << endl;

	// cargamos los arboles correspondientes a la via v31
 	v3->insertarArboles(a31);
 	v3->insertarArboles(a32);

	// repetimos el las pruebas que hemos echo en en v2, pero ahora con los dos arboles de v3
	if(!v3->BuscarArbol(a31->getGenero()))
		cout << "ERROR en buscar arbol en v3 (prueba 1)" << endl;

    if(!v3->BuscarArbol(a32->getGenero()))
		cout << "ERROR en buscar arbol en v3 (prueba 2)" << endl;

	// ahora vamos a comprobar otro genero y vemos que no lo encuentra
	if(v3->BuscarArbol("ACER"))
		cout << "ERROR en buscar arbol en v3 (prueba 3)" << endl;

cout << "--------------- FIN BUSCAR ARBOLES ---------------" << endl;

}

void pruebasNumeroArbolesV(){

	cout << "--------------- INICIO NUMERO ARBOLES ---------------" << endl;

	Via *v1, *v2, *v3;

	Arbol *a31, *a32, *a2; // Arboles de las vias v2 y v3

	// 3464 Sophora_japonica Leguminosae SOFORA SOPHORA 0.9 7 5 NO RIEGO 1
	a2 = new Arbol ("Sophora_japonica", "Leguminosae", "SOFORA", "SOPHORA",
										0.9, 7, 5, "NO RIEGO", 1, 3464);
	// 111 Ulmus_pumila Ulmaceae OLMO DE SIBERIA ULMUS 1 7 5 NO RIEGO 1
	a31 = new Arbol ("Ulmus_pumila", "Ulmaceae", "OLMO DE SIBERIA", "ULMUS",
 										1, 7, 5, "NO RIEGO", 1, 111);
  // 111 Liquidambar_styraciflua Hamamelidaceae LIQUIDAMBAR LIQUIDAMBAR 0.14 1 1 NO RIEGO 1
	a32 = new Arbol ("Liquidambar_styraciflua", "Hamamelidaceae", "LIQUIDAMBAR", "LIQUIDAMBAR",
 										0.14, 1, 1, "NO RIEGO", 1, 111);

	/*********** Via Amapola **********
		346249 	Calle 	619.56*/
	v1 = new Via (49, "Amapola", 619.56, "Calle", 2568);

	/*********** Via Clavel **********
		346449 	Calle 	396.79*/
	v2 = new Via (49, "Clavel", 396.79, "Calle", 3464);

	/*********** Via Carreteros **********
		011169 	Calle 	32.79 */
	v3 = new Via (69, "Carreteros", 32.79, "Calle", 0111);


	// --------------------- 1º VIA -------------------------------

 	// vemos que la via v1 no tiene ningun arbol
 	if(!v1->estaVacia())
 		cout << "ERROR El conjunto de arboles de v31 no está vacio" << endl;


//	// el nº de arboles al no insertar ningun arbol es 0
	if(v1->numeroArboles() != 0)
	cout << "ERROR en numero de arboles de la via v1 (Amapola)" << endl;

	// ------------------------ 2º VIA -----------------------------------


	// vemos que v2 esta vacia
	if(!v2->estaVacia())
		cout << "ERROR El conjunto de arboles de v2 no está vacio" << endl;

	// cargamos los arboles correspondientes a la via v2
	v2->insertarArboles(a2);

	// vemos se ha insertado bien el arbol
	if(v2->estaVacia())
		cout << "ERROR El conjunto de arboles de v2 está vacio" << endl;

//	// el nº de arboles para este caso debe ser 1
	if(v2->numeroArboles() != a2->getUnidades())
	 cout << "ERROR en numero de arboles de la via v2 (Clavel)" << endl;

	 // ---------------------------- 3º VIA ------------------------------------

	// vemos que la via v32 no tiene ningun arbol
	if(!v3->estaVacia())
		cout << "ERROR El conjunto de arboles de v3 no esta vacio (Carreteros)" << endl;

 	// cargamos los arboles correspondientes a la via v31
 	v3->insertarArboles(a31);
 	v3->insertarArboles(a32);

 	// y ahora vemos que se han insertado los arboles
 	if(v3->estaVacia())
 		cout << "ERROR El conjunto de arboles de v31 está vacio" << endl;

// el nº de arboles para este caso debe ser la suma de los arboles de las dos vias anteriormente mencionadas
 if(v3->numeroArboles() != (a31->getUnidades() + a32->getUnidades()))
 		cout << "ERROR en numero de arboles de via v3 (Carreteros)" << endl;

	delete v1;
	delete v2;
	delete v3;

	 cout << "--------------- FIN NUMERO ARBOLES ---------------" << endl;
}


void pruebasEstaVacioV(){

	cout << "-------------INICIO PRUEBA ESTA VACIO-----------------" << endl;

	Via *v;
	Arbol *a;

	// creamos una via
	v = new Via();

  // ahora vemos si la via está vacia
	if(!v->estaVacia())
		cout << "ERROR fallo en esta vacio (Prueba 1)" << endl;

 // creamos una arbol
	a = new Arbol();

 // insertamos el arbol a en la via v
	v->insertarArboles(a);

 // comprobamos que una vez insertada el arbol a en la via v, ya no se encuentra vacia
	if(v->estaVacia())
	  cout << "ERROR fallo en esta vacio (Prueba 2)" << endl;

	delete v;

	cout << "-------------FIN PRUEBA ESTA VACIO-----------------" << endl;


}

void pruebasInsertarArbolesV(){

cout << "-------------INICIO PRUEBA INSERTAR ARBOLES --------------" << endl;


	Via *v31, *v32; // Vias del barrio b3

	/*********** Via Carreteros **********
		011169 	Calle 	32.79 */
	v31 = new Via (69, "Carreteros", 32.79, "Calle", 0111);

	/*	********** Via Aperadores **********
		005069 	Calle 	43.57*/
	v32 = new Via (69, "Aperadores", 43.57, "Calle", 0050);

	Arbol *a31, *a32, *a33, *a34; // Arboles de las vias v31 y v32

	// 111 Ulmus_pumila Ulmaceae OLMO DE SIBERIA ULMUS 1 7 5 NO RIEGO 1
	a31 = new Arbol ("Ulmus_pumila", "Ulmaceae", "OLMO DE SIBERIA", "ULMUS",
 										1, 7, 5, "NO RIEGO", 1, 111);
  // 111 Liquidambar_styraciflua Hamamelidaceae LIQUIDAMBAR LIQUIDAMBAR 0.14 1 1 NO RIEGO 1
	a32 = new Arbol ("Liquidambar_styraciflua", "Hamamelidaceae", "LIQUIDAMBAR", "LIQUIDAMBAR",
 										0.14, 1, 1, "NO RIEGO", 1, 111);
	// 50 Sophora_japonica Leguminosae SOFORA SOPHORA 0.9 7 5 NO RIEGO 1
	a33 = new Arbol ("Sophora_japonica", "Leguminosae", "SOFORA", "SOPHORA",
 										0.9, 7, 5, "NO RIEGO", 1, 50);
	// 50 Gleditsia_triacanthos Caesalpiniaceae ACACIA DE TRES ESPINAS GLEDITSIA 0.75 7 3 NO RIEGO 1
	a34 = new Arbol ("Gleditsia_triacanthos", "Caesalpiniaceae", "ACACIA DE TRES ESPINAS", "GLEDITSIA",
 										0.75, 7, 3, "NO RIEGO", 1, 50);

	cout << "-------------INICIO INSERCION A31 A32 --------------" << endl;

	// vemos que la via v32 no tiene ningun arbol
	if(!v31->estaVacia())
		cout << "ERROR El conjunto de arboles de v32 no está vacio" << endl;

	// mostramos para ver que no tiene ningun arbol
	v31->mostrar();


	// cargamos los arboles correspondientes a la via v32
		 v31->insertarArboles(a31);
		 v31->insertarArboles(a32);

		 // vemos que la via v32 no tiene ningun arbol
	 	if(v31->estaVacia())
	 		cout << "ERROR El conjunto de arboles de v32 está vacio" << endl;

	 	// mostramos para ver que tiene arboles
	 	v31->mostrar();

	cout << "-------------FIN INSERCION A31 A32 --------------" << endl;
	cout << "-------------INICIO INSERCION A33 A34 --------------" << endl;

	// vemos que la via v32 no tiene ningun arbol
	if(!v32->estaVacia())
	cout << "ERROR El conjunto de arboles de v32 no está vacio" << endl;

	// mostramos para ver que no tiene ningun arbol
	v32->mostrar();


	// cargamos los arboles correspondientes a la via v32
	 v32->insertarArboles(a33);
	 v32->insertarArboles(a34);

	 // vemos que la via v32 no tiene ningun arbol
 	if(v32->estaVacia())
 		cout << "ERROR El conjunto de arboles de v32 está vacio" << endl;

 	// mostramos para ver que tiene arboles
 	v32->mostrar();

	cout << "-------------FIN INSERCION A33 A34 --------------" << endl;

	delete v31;
	delete v32;
}


void pruebasPorDefectoV(){

	cout << "-------------INICIO PRUEBA VIAS POR DEFECTO -----------------" << endl;

	Via *v;

	// 1º PRUEBA (CONSTRUCTOR POR DEFECTO)

	v = new Via();

	if(v->getNombreVia() != "")
		cout << "ERROR en atributo nombre (constructor por defecto)" << endl;

	if(v->getTipoVia() != "")
	  cout << "ERROR en atributo tipoVia (constructor por defecto)" << endl;

	if(v->getCodigoBarrio() != 0)
		cout << "ERROR en atributo codigoBarrio (constructor por defecto)" << endl;

	if(v->getCodigoVia() != 0.0)
		cout << "ERROR en atributo codigoVia (constructor por defecto)" << endl;

	if(atoi(v->getClave().c_str()) != 0)
		cout << "ERROR en clave (constructor por defecto)" << endl;

	if(v->getLongitudVia() != 0.0)
		cout << "ERROR en atributo longitudVia (constructor por defecto)" << endl;

	if(!v->estaVacia())
		cout << "ERROR en atributo conjuntoArboles (constructor por defecto)" << endl;

	delete v;

		cout << "-------------FIN PRUEBA VIAS POR DEFECTO -----------------" << endl;

}

void pruebasParametrizadoV(){

	cout << "-------------INICIO PRUEBA VIAS PARAMETRIZADO -----------------" << endl;

	Via *v;

	// 2º PRUEBA (CONSTRUCTOR PARAMETRIZADO)

	v = new Via(30, "Ruta De La Plata", 1731.1, "Avda" , 1901);

	if(v->getNombreVia() != "Ruta De La Plata")
		cout << "ERROR en atributo nombre (constructor parametrizado)" << endl;

	if(v->getTipoVia() != "Avda")
	  cout << "ERROR en atributo tipoVia (constructor parametrizado)" << endl;

	if(v->getCodigoBarrio() != 30)
		cout << "ERROR en atributo codigoBarrio (constructor parametrizado)" << endl;

	if(v->getCodigoVia() != 1901)
		cout << "ERROR en atributo codigoVia (constructor parametrizado)" << endl;

	if(atoi(v->getClave().c_str()) != 190130)
		cout << "ERROR en clave (constructor parametrizado)" << endl;

	if(v->getLongitudVia() > (1731.1 + ERROR))
		cout << "ERROR en atributo longitudVia (constructor parametrizado)" << endl;

	if(!v->estaVacia())
		cout << "ERROR en atributo conjuntoArboles (constructor parametrizado)" << endl;

	delete v;

	cout << "-------------FIN PRUEBA VIAS PARAMETRIZADO -----------------" << endl;


}

void pruebasSetGetV(){

	cout << "-------------INICIO PRUEBA VIAS SET / GET -----------------" << endl;

	Via *v;

	//3º PRUEBA METODOS SET/GET

	v = new Via();

		v->setNombreVia("Picos De Europa");
	  v->setTipoVia("Calle");
		v->setCodigoBarrio(29);
		v->setCodigoVia(3600);
		v->setLongitudVia(211.88);

	  if(v->getNombreVia() != "Picos De Europa")
	  	cout << "ERROR en atributo nombre (SET/GET)" << endl;

	  if(v->getTipoVia() != "Calle")
	    cout << "ERROR en atributo tipoVia (SET/GET)" << endl;

	  if(v->getCodigoBarrio() != 29)
	  	cout << "ERROR en atributo codigoBarrio (SET/GET)" << endl;

	  if(v->getCodigoVia() != 3600)
	  	cout << "ERROR en atributo codigoVia (SET/GET)" << endl;

		if(atoi(v->getClave().c_str()) != 360029)
			cout << "ERROR en clave (SET/GET)" << endl;

	  if(v->getLongitudVia() > (211.88 + ERROR))
	  	cout << "ERROR en atributo longitudVia (SET/GET)" << endl;

	  if(!v->estaVacia())
	  	cout << "ERROR en atributo conjuntoArboles (SET/GET)" << endl;

	  delete v;

	cout << "-------------FIN PRUEBA VIAS SET / GET -----------------" << endl;


}
