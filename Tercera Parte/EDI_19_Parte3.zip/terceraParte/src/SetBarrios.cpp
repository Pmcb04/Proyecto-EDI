/*
 * setBarrios.cpp
 *
 *  Created on: 11 mar. 2019
 *     Authors:  - Pedro Miguel Carmona Broncano
 *							 - Ruben Marin Lucas
 */

#include "SetBarrios.h"


SetBarrios::SetBarrios() {

    cont = 0;
}

SetBarrios::~SetBarrios() {

    for (int i = 0; i < cont; i++) {

        delete setBarrios[i];

    }

}

bool SetBarrios::estaVacia() {

    return cont == 0;
}

int SetBarrios::numElementos() {

    return cont;

}

void SetBarrios::insertarBarrios(Barrio* b) {

    int i = 0;
    bool enc = false;

    while (i < cont && !enc){

        if(setBarrios[i]->getNombre() > b->getNombre()){

            enc = true;

        }else{

            i++;

        }

    }


    if(enc){

        for (int j = cont; j > i; j--) {

            setBarrios[j] = setBarrios[j-1];

        }

    }

    setBarrios[i] = b;
    cont++;

}

bool SetBarrios::existeBarrio(int codigo) {

    bool existe = false;
    int i = 0;

    while(i < cont && !existe){

        if(setBarrios[i]->getCodigo() == codigo){

            existe = true;

        }else{

            i++;

        }


    }

    return existe;

}


bool SetBarrios::existeBarrio(string nombre) {

    bool existe = false;
    int i = 0;

    while(i < cont && !existe){

        if(setBarrios[i]->getNombre() == nombre){

            existe = true;

        }else{

            i++;

        }


    }

    return existe;

}



void SetBarrios::get(int pos, Barrio*& b) {

    b = setBarrios[pos];

}

void SetBarrios::getBarrio(int codigo, Barrio*& b) {

    bool enc = false;
    int i = 0;

    while(i < cont && !enc){

        if(setBarrios[i]->getCodigo() == codigo){

            b = setBarrios[i];
            enc = true;
        }

        i++;
    }

}

void SetBarrios::eliminar(string nombre) {

    int i = 0;
    bool enc = false;

    while(i < cont && !enc){

        if(setBarrios[i]->getNombre() == nombre){

            enc = true;

        }else{

            i++;

        }

    }

    if(enc){

        for (int j = i; j < cont ; j++){

            setBarrios[j] = setBarrios[j+1];

        }

        cont--;

    }


}

void SetBarrios::mostrar() {

    for (int i = 0; i < cont; i++) {

      setBarrios[i]->mostrar();

	}
}
