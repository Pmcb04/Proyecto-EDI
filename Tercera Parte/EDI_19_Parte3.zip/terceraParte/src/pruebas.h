/*
 * pruebas.h
 *
 *  Created on: 18 feb. 2019
 *      Authors:  - Pedro Miguel Carmona Broncano
 									- Ruben Marin Lucas
 */


#ifndef PRUEBAS_H_
#define PRUEBAS_H_

#include <fstream>
#include <iostream>
#include "pruebasVias.h"
#include "pruebasBarrios.h"
#include "pruebasArboles.h"
#include "pruebasSetBarrios.h"
using namespace std;

//Menu para seleccionar entre los diferentes modulos de pruebas
void pruebas();

#endif /* PRUEBAS_H_ */
