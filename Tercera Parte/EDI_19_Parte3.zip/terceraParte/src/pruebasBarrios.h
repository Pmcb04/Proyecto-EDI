/*
 * pruebasBarrios.h
 *
 *  Created on: 18 feb. 2019
 *      Authors:  - Pedro Miguel Carmona Broncano
 									- Ruben Marin Lucas
 */

#ifndef PRUEBASBARRIOS_H_
#define PRUEBASBARRIOS_H_

#include "Barrio.h"


/*Se crea un barrio por constructor por defecto y
se comprueba , que todos los parametros se inician correctamente*/
void pruebasPorDefectoB();

/*Se crea un barrio por constructor parametrizado y
se comprueba, que todos los parametros se inician correctamente */
void pruebasParametrizadoB();

/*Se crea un barrio por constructor por defecto y
se introducen los parametros por los metodos set y se comprueban de que
todos los parametros se inician correctamente*/
void pruebasSetGetB();

/*Se crean barrios con vias y se comprueban de que las vias introducidas
 están en el barrio correspondiente  */
void pruebasBuscarViasB();

/*Se crean barrios con vias y arboles y se comprueban de que el nº de
arboles introducidos en cada barrio es correcto*/
void pruebasNumeroArbolesB();

/*Se crean barrios, se introducen vias y se comprueba de que las
 vias se han insertado correctamente*/
void pruebasInsertarViasB();

/*Se crea un barrio y se introducen vias y se comprueba antes y
despues de esta insercion se comprueba de que esté o no vacio el barrio*/
void pruebasEstaVacioB();

// llamada a todos los modulos de prueba de esta clase
void pruebasBarrios();

#endif /* PRUEBASBARRIOS_H_ */
