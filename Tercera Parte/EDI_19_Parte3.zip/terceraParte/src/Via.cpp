/*
 * Via.cpp
 *
 *  Created on: 25 feb. 2019
 *       Authors:  - Pedro Miguel Carmona Broncano
 *							   - Ruben Marin Lucas
 */

#include "Via.h"

Via::Via() {

	codigoBarrio = 0;
	codigoVia = 0;
	longitudVia = 0.0;
	nombreVia = "";
	conjuntoArboles = NULL;

}

Via::Via(int codigoBarrio, string nombreVia,float longitudVia,string tipoVia, int codigoVia) {

	this->codigoBarrio = codigoBarrio;
	this->nombreVia = nombreVia;
	this->codigoVia = codigoVia;
	this->longitudVia = longitudVia;
	this->tipoVia = tipoVia;
	this->conjuntoArboles = NULL;
}

Via::~Via() {

  Arbol *a;

	if(conjuntoArboles != NULL){

             conjuntoArboles->moverInicio();

             while (!conjuntoArboles->estaVacia()) {

                conjuntoArboles->consultar(a);
                delete a;
                conjuntoArboles->borrar();

             }

            delete conjuntoArboles;

	}

}

bool Via:: estaVacia(){

	bool bandera = true;

	if(conjuntoArboles != NULL){

		bandera = false;

	}

	return bandera;

}


void Via::setCodigoBarrio(int codigoBarrio) {

	this->codigoBarrio = codigoBarrio;
}

void Via::setCodigoVia(int codigoVia) {

	this->codigoVia = codigoVia;
}

void Via::setLongitudVia(float longitudVia) {

	this->longitudVia = longitudVia;
}

void Via::setNombreVia(string nombreVia) {

	this->nombreVia = nombreVia;
}

void Via::setTipoVia(string tipoVia) {

	this->tipoVia = tipoVia;
}

int Via::getCodigoBarrio() {

	return codigoBarrio;
}

int Via::getCodigoVia() {

	return codigoVia;
}

float Via::getLongitudVia() {

	return longitudVia;
}

string Via::getNombreVia() {

	return nombreVia;

}

string Via::getTipoVia() {

	return tipoVia;
}

string Via::getClave() {

	string claveBarrio, claveVia, clave;
	string cero = "0";
	int i;

	if(codigoBarrio < 10){

		claveBarrio = cero + to_string(codigoBarrio);

	}else{

		claveBarrio = to_string(codigoBarrio);
	}

	claveVia = to_string(codigoVia);

	 i = 4-claveVia.length();

	while (i > 0){

			claveVia = cero + claveVia;
			i--;
	}

	clave = claveVia + claveBarrio;

	return clave;

}


void Via:: mostrar(){

	cout << "********** Via " << this->getNombreVia() << " **********" << endl;
	cout << this->getClave();
	cout << " ";
	cout << this->getTipoVia();
	cout << " ";
	cout << this->getLongitudVia();
	cout << endl;

	if(conjuntoArboles != NULL){

		cout << "\t\t ********** Arboles de la via " << this->getNombreVia() << " **********" << endl << endl;

		conjuntoArboles->moverInicio();
		Arbol *a;

		while(!conjuntoArboles->finLista()){

				conjuntoArboles->consultar(a);
				a->mostrar();
				conjuntoArboles->avanzar();
		}
		cout << endl;

  }

}


void Via:: insertarArboles(Arbol *a){
	Arbol *aux;
	bool enc = false;

	if(conjuntoArboles == NULL ){

		conjuntoArboles = new ListaPI <Arbol*>;

	}

	conjuntoArboles->moverInicio();

	while(!conjuntoArboles->finLista() && !enc){

		conjuntoArboles->consultar(aux);

		if( a->getCodigoVia() < aux->getCodigoVia() ){

			enc = true;

		}else{

			conjuntoArboles->avanzar();
		}

	}

	conjuntoArboles->insertar(a);

}

void Via:: ficheroArboles(){

	int cont = 0;
	bool enc = false;
  string nombre = "Arboles " + this->getNombreVia() + ".txt";
	const char *datname;
	datname = nombre.c_str();
  ofstream flujoArboles;
  flujoArboles.open(nombre.c_str());

  if(!flujoArboles.fail()){


		if(!this->estaVacia()){

				enc = true;

				flujoArboles << "-------------- Arboles pertenecientes a la via "  << nombreVia << " ------------------------" <<  endl;

				Arbol *a;

				conjuntoArboles->moverInicio();
				while(!conjuntoArboles->finLista()){

					conjuntoArboles->consultar(a);
					cont += a->getUnidades();

					flujoArboles  << a->getCodigoVia();
					flujoArboles << " ";
					flujoArboles << a->getEspecie();
					flujoArboles << " ";
					flujoArboles << a->getFamilia();
					flujoArboles << " ";
					flujoArboles << a->getNombreComun();
					flujoArboles << " ";
					flujoArboles << a->getGenero();
					flujoArboles << " ";
					flujoArboles << a->getRiego();
					flujoArboles << " ";
					flujoArboles << a->getDiametro();
					flujoArboles << " ";
					flujoArboles << a->getAltura();
					flujoArboles << " ";
					flujoArboles << a->getCopa();
					flujoArboles << " ";
					flujoArboles <<  a->getUnidades();
					flujoArboles << endl;

					conjuntoArboles->avanzar();
				}

				flujoArboles  << "---------------------------------------------" << endl;
			  flujoArboles << "TOTAL ARBOLES VIA " << this->getNombreVia() << ":" << cont << endl;
			  cout << "¡¡¡ " + nombre +  " Creado !!!" << endl;

		}else{

				cout << "No hay arboles que pertenezcan a la calle " << nombreVia << endl;
		}

		flujoArboles.close();
 }
	if(!enc)
		remove (datname);
}


void Via::insertarLista(ListaPI <Nodo*> *&lista, Nodo *n){

  Nodo *aux;
  bool enc = false;

  lista->moverInicio();

  while(!lista->finLista() && !enc){

    lista->consultar(aux);

    if(aux->nombreVia > n->nombreVia)
      enc = true;
    else
      lista->avanzar();

   }
    lista->insertar(n);
}


void Via::Especies(string especie, ListaPI<Nodo*> *&lista, bool &enc){

	Arbol *a;
  int cont = 0;
	Nodo *aux;

		if(!this->estaVacia()){

			conjuntoArboles->moverInicio();
			while(!conjuntoArboles->finLista()){

				conjuntoArboles->consultar(a);

				if(a->getEspecie() == especie)
					cont += a->getUnidades();

				conjuntoArboles->avanzar();

			}

			if(cont > 0){
				enc = true;
				aux = new Nodo();
				aux->nombreVia = this->getNombreVia();
				aux->arboles = cont;
				insertarLista(lista, aux);
			}

		}

}

bool Via::BuscarArbol(string genero){

	Arbol *a;
	bool enc = false;

		conjuntoArboles->moverInicio();
		while (!conjuntoArboles->finLista() && !enc){

			conjuntoArboles->consultar(a);

			if(a->getGenero() == genero){

				enc = true;

			}
			conjuntoArboles->avanzar();

		}

	return enc;
}

int Via:: numeroArboles (){

	Arbol *a;
	int cont = 0;

		if(!this->estaVacia()){
			conjuntoArboles->moverInicio();
			while(!conjuntoArboles->finLista()){
				conjuntoArboles->consultar(a);
				cont += a->getUnidades();
				conjuntoArboles->avanzar();
			}
		}
		return cont;
}
