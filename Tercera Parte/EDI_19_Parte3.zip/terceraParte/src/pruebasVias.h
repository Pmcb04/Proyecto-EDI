/*
 * pruebasVias.h
 *
 *  Created on: 18 feb. 2019
 *      Authors:  - Pedro Miguel Carmona Broncano
 									- Ruben Marin Lucas
 */

#ifndef PRUEBASVIAS_H_
#define PRUEBASVIAS_H_

#include "Via.h"

/*Se crea una via por constructor por defecto y
se comprueba , que todos los parametros se inician correctamente*/
void pruebasPorDefectoV();

/*Se crea una via por constructor parametrizado y
se comprueba, que todos los parametros se inician correctamente */
void pruebasParametrizadoV();

/*Se crea una via por constructor por defecto y
se introducen los parametros por los metodos set y se comprueban de que
todos los parametros se inician correctamente*/
void pruebasSetGetV();

/*Se crean vias, se introducen arboles y se comprueba de que los arboles
 se han insertado correctamente*/
void pruebasInsertarArbolesV();

/*Se crean vias con arboles y se comprueban de que el nº de
arboles introducidos en cada via es correcto*/
void pruebasNumeroArbolesV();

/*Se crea una via y se introducen arboles y se comprueba antes y
despues de esta insercion que esté o no vacio la via*/
void pruebasEstaVacioV();
/* */

/*Se crean vias y se introducen arboles en cada una, una vez introducidos,
se buscan con el metodo BuscarArbol */
void pruebasBuscarArbolV();

// llamada a todos los modulos de prueba de esta clase
void pruebasVias();


#endif /* PRUEBASVIAS_H_ */
