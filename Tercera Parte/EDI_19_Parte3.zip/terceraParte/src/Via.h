/*
 * Via.h
 *
 *  Created on: 25 feb. 2019
 *      Authors:  - Pedro Miguel Carmona Broncano
 *							  - Ruben Marin Lucas
 */

#ifndef VIA_H_
#define VIA_H_

#include <iostream>
#include <fstream>
using namespace std;
#include "listapi.h"
#include "Arbol.h"


struct Nodo{
  string nombreVia;
  int arboles;
};


class Via {

private:

	int codigoBarrio;
	int codigoVia;
	float longitudVia;
	string nombreVia;
	string tipoVia;
	ListaPI <Arbol*> *conjuntoArboles;


public:


	/*
	 * PRE: {  }
	 * POST:{ Constructor por defecto }
	 * COMPLEJIDAD:O(1)
	 */
	Via();

	/*
	 * PRE: {  }
	 * POST:{ Constructor parametrizado }
	 * COMPLEJIDAD:O(1)
	 */
	Via(int codigoBarrio, string nombreVia, float longitudVia, string tipoVia, int codigoVia);

	/*
	 * PRE: {  }
	 * POST:{ Destructor por defecto }
	 * COMPLEJIDAD:O(n)
	 */
	~Via();

	//metodos setter

	/*
	 * PRE: { La variable "codigoBarrio" inicializada correctamente }
	 * POST:{ Introduce el contenido de la
	 *       variable "codigoBrrio" en el atributo -codigoBarrio- }
	 * COMPLEJIDAD:O(1)
	 */
	void setCodigoBarrio(int codigoBarrio);

	/*
	 * PRE: { La variable "codigoVia" inicializada correctamente }
	 * POST:{ Introduce el contenido de la
	 *       variable "codigovias" en el atributo -codigoVia- }
	 * COMPLEJIDAD:O(1)
	 */
	void setCodigoVia(int codigoVia);

	/*
	 * PRE: { La variable "longitudVia" inicializada correctamente }
	 * POST:{ Introduce el contenido de la
	 *       variable "longitudVia" en el atributo -longitudVia- }
	 * COMPLEJIDAD:O(1)
	 */
	void setLongitudVia(float longitudVia);

	/*
	 * PRE: { La variable "nombreVia" inicializada correctamente }
	 * POST:{ Introduce el contenido de la
	 *       variable "nombreVia" en el atributo -nombreVia- }
	 * COMPLEJIDAD:O(1)
	 */
	void setNombreVia(string nombreVia);

	/*
	 * PRE: { La variable "tipoVia" inicializada correctamente }
	 * POST:{ Introduce el contenido de la
	 *       variable "tipoVia" en el atributo -tipoVia- }
	 * COMPLEJIDAD:O(1)
	 */
	void setTipoVia(string tipoVia);

	//metodos getter


	/*
	 * PRE: { La via  debe tener el atributo -codigoBarrio- inicializado }
	 * POST:{ Devuelve el contenido del atributo -codigoBarrio- }
	 * COMPLEJIDAD:O(1)
	 */
	int getCodigoBarrio();

	/*
	 * PRE: { La via  debe tener el atributo -codigoVia- inicializado }
	 * POST:{ Devuelve el contenido del atributo -codigoVia- }
	 * COMPLEJIDAD:O(1)
	 */
	int getCodigoVia();

	/*
	 * PRE: { La via debe tener el atributo -longitud- inicializado }
	 * POST:{ Devuelve el contenido del atributo -longitud- }
	 * COMPLEJIDAD:O(1)
	 */
	float getLongitudVia();

	/*
	 * PRE: { La via debe tener el atributo -nombreVia- inicializado }
	 * POST:{ Devuelve el contenido del atributo -nombreVia- }
	 * COMPLEJIDAD:O(1)
	 */
	string getNombreVia();

	/*
	 * PRE: { La via debe tener el atributo -tipoVia- inicializado }
	 * POST:{ Devuelve el contenido del atributo -tipoVia- }
	 * COMPLEJIDAD:O(1)
	 */
	string getTipoVia();

	/*
	 * PRE: { La via debe tener el atributo -codigoBarrio- y -codigoVia- inicializados }
	 * POST:{ Devuelve codigoBarrio + codigoVia}
	 * COMPLEJIDAD:O(1)
	 */
	string getClave();


	/*
	 * PRE: { }
	 * POST:{ Devuelve true en caso de que la via no tenga arboles y false en caso contrario}
	 * COMPLEJIDAD:O(1)
	 */
	bool estaVacia();


	/*
	 * PRE: { La via debe estar inicializado, el atributo -colaArboles- no puede estar estaVacio
 	*        , es decir, colaArboles != NULL  }
	 * POST:{ Muestra por pantalla la información de la via }
	 * COMPLEJIDAD:O(1)
	 */
	void mostrar();


 /*
 	* PRE: { El puntero "a" debe estar incializado correctamente }
 	* POST:{ Inserta en la via los arboles correspondientes a esta, si no hay
	*        arboles para esta via no se inserta ninguno }
 	* COMPLEJIDAD:O(n)
 	*/
	void insertarArboles(Arbol *a);

  /*
   * PRE: { El puntero "lista"  y la variable "especie" inicializado correctamente }
   * POST:{ Devuelve un puntero hacia una lista con las vias que contienen arboles
   *        de una determinada especie, ademas en caso de encontrar lo deseado devolvera
   *        true, en caso de no encontrar ningun arbol de esa especie en esa via devolvera
   *        false }
   * COMPLEJIDAD:O(n)
   */
	void Especies(string especie, ListaPI<Nodo*> *&lista, bool &enc);

  /*
   * PRE: { Los punteros "n" y "lista" deben estar incializados correctamente }
   * POST:{ Inserta en la via los arboles correspondientes a esta, si no hay
   *        arboles para esta via no se inserta ninguno }
   * COMPLEJIDAD:O(n)
   */
  void insertarLista(ListaPI <Nodo*> *&lista, Nodo *n);

  /*
   * PRE: {  }
   * POST:{ Escribe en un fichero los datos de los arboles de la via }
   * COMPLEJIDAD:O(n)
   */
	void ficheroArboles();

  /*
   * PRE: { La variable "genero" incializada correctamente }
   * POST:{ Devuelve true en caso de encontrar un arbol de un determinado genero }
   * COMPLEJIDAD:O(n)
   */
  bool BuscarArbol(string genero);

  /*
   * PRE: { }
   * POST:{ Devuelve el numero de arboles que tiene una via }
   * COMPLEJIDAD:O(n)
   */
	int numeroArboles();

  /*
   * PRE: { El puntero "a" debe estar incializado correctamente }
   * POST:{ Inserta en la via los arboles correspondientes a esta, si no hay
   *        arboles para esta via no se inserta ninguno }
   * COMPLEJIDAD:O(n)
   */
	void ficheroDatos(ofstream &flujoDatos);

};

#endif /* VIA_H_ */
