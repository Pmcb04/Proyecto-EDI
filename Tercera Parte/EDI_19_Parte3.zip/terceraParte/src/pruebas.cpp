/*
 * pruebas.cpp
 *
 *  Created on: 18 feb. 2019
 *      Authors:  - Pedro Miguel Carmona Broncano
 									- Ruben Marin Lucas
 */


#include "pruebas.h"


void pruebas(){


  int opcion;
  bool salir = false;
  cout << "----------------------------------------------------------------------------------------------------------------" << endl;
  cout << "Para las pruebas de cada clase, se ha realizado las pruebas de los constructores y los metodos get/set" << endl;
  cout << "Para las pruebas de SetBarrios, se ha realizado un cjtoBarrios en donde se prueban los distintos casos: " << endl;
  cout << "\tUn barrio sin vias" << endl;
  cout << "\tUn barrio con vias, pero sin arboles"<<endl;
  cout << "\tUn barrio con vias y con arboles"<<endl;
  cout << "----------------------------------------------------------------------------------------------------------------" << endl << endl;



  do {

    cout << "Elige Opción:" << endl;
    cout << "\t 1. Pruebas Barrios" << endl;
    cout << "\t 2. Pruebas Vias" << endl;
    cout << "\t 3. Pruebas Arboles" << endl;
    cout << "\t 4. Pruebas SetBarrios" << endl;
    cout << "\t 5. Salir" << endl;

    cin >> opcion;


    switch (opcion) {
      case 1: //PRUEBAS BARRIOS
          pruebasBarrios();
        break;
      case 2: // PRUEBAS VIAS
          pruebasVias();
        break;
      case 3: // PRUEBAS ARBOLES
          pruebasArboles();
        break;
      case 4: // PRUEBAS SETBARRIOS
          pruebasSetBarrios();
        break;
      case 5: //SALIR
          salir = true;
        break;
      default:
      cout << "Esa opción no está diponible. Por favor marca una opción de la lista. " << endl;
        break;
    }

  } while(!salir);

}
