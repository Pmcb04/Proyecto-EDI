/*
 * Barrio.cpp
 *
 *  Created on: 18 feb. 2019
 *       Authors:  - Pedro Miguel Carmona Broncano
 *							   - Ruben Marin Lucas
 */

#include "Barrio.h"
#include <fstream>

Barrio::Barrio() {

	nombre = "";
	nombreDistrito = "";
	area = 0.0;
	perimetro = 0.0;
	codigo = 0;
	conjuntoVias = NULL;
}


Barrio::Barrio(string nombre, float area, float perimetro, int codigo, string distrito) {

	this->nombre = nombre;
	this->area = area;
	this->perimetro = perimetro;
	this->codigo = codigo;
	this->nombreDistrito = distrito;
	conjuntoVias = NULL;
}


Barrio::~Barrio() {

  Via *v;

	if(conjuntoVias != NULL){

            while (!conjuntoVias->vacio()) {

							v = conjuntoVias->raiz();
				      conjuntoVias->borrar(v);
				      delete v;

			      }
         delete conjuntoVias;
	}

}


void Barrio::setNombre(string nombre) {

	this->nombre = nombre;
}


void Barrio::setArea(float area) {

	this->area = area;

}


void Barrio::setPerimetro(float perimetro) {

	this->perimetro = perimetro;

}


void Barrio::setDistrito(string distrito) {

	this->nombreDistrito = distrito;

}


void Barrio::setCodigo(int codigo){

	this->codigo = codigo;

}

void Barrio::mostrarinOrden(ArbolB<Via*, Comparar> *conjuntoVias) {

	if (!conjuntoVias->vacio() ){

		if (conjuntoVias->hijoIzq()!=NULL){
				 mostrarinOrden(conjuntoVias->hijoIzq());
		}

		conjuntoVias->raiz()->mostrar();

		if (conjuntoVias->hijoDer()!=NULL){
				 mostrarinOrden(conjuntoVias->hijoDer());
		}

	}

}


void Barrio::mostrar(){


					cout << "------------- Barrio " << this->getNombre() << " ------------" << endl;
	        cout << this->getCodigo();
	        cout << " ";
	        cout << this->getDistrito();
	        cout << " ";
	        cout << this->getArea();
	        cout << " ";
	        cout << this->getPerimetro();
	        cout << endl;

					if(conjuntoVias != NULL){

								cout << "********** Vias del barrio " << this->getNombre() << " **********" << endl << endl;

								mostrarinOrden(conjuntoVias);

	       }

}


string Barrio::getNombre() {

	return nombre;
}


float Barrio::getArea() {

	return area;

}


float Barrio::getPerimetro() {

	return perimetro;
}


int Barrio::getCodigo() {

	return codigo;
}

string Barrio::getDistrito() {

	return nombreDistrito;
}


bool Barrio::buscarVia(ArbolB<Via*, Comparar> *conjuntoVias, int codigoVia, Via *&v){

	ArbolB<Via*, Comparar> *aux;
	Via *vaux;
	bool enc = false;

	if(!conjuntoVias->vacio()){
		vaux = conjuntoVias->raiz();
		if(vaux->getCodigoVia() == codigoVia){
             v = vaux;
             enc = true;
		}else{
			if(conjuntoVias->hijoIzq()!=NULL){
				 aux = conjuntoVias->hijoIzq();
				enc = buscarVia(aux, codigoVia, v);
		  }
			if(conjuntoVias->hijoDer()!=NULL){
			    aux = conjuntoVias->hijoDer();
					enc = buscarVia(aux, codigoVia, v);
		  }
		}
	}
	return enc;
}


bool Barrio::buscarVia(int codigoVia, Via *&v){

	  bool enc;

	   if(!conjuntoVias->vacio()){
		   enc = buscarVia(conjuntoVias, codigoVia, v);
	   }

	  return enc;
}

bool Barrio::buscarVia(ArbolB<Via*, Comparar> *conjuntoVias, string nombreVia, Via *&v){

	ArbolB<Via*, Comparar> *aux;
	Via *vaux;
	bool enc = false;

	if(!conjuntoVias->vacio()){
		vaux = conjuntoVias->raiz();
		if(vaux->getNombreVia() == nombreVia){
             v = vaux;
             enc = true;
		}else{
			if(vaux->getNombreVia() > nombreVia){
				 aux = conjuntoVias->hijoIzq();
			}else{
			     aux = conjuntoVias->hijoDer();

			}if(aux != NULL){
				 enc = buscarVia(aux, nombreVia, v);
		    }
		}

	}

	return enc;
}


bool Barrio::buscarVia(string nombre, Via *&v){

	  bool enc;

	   if(!conjuntoVias->vacio()){
		   enc = buscarVia(conjuntoVias, nombre, v);
	   }

	  return enc;
}


bool Barrio::estaVacio(){

	bool bandera = true;

	if(conjuntoVias != NULL){
		bandera = false;
	}
	return bandera;
}


void Barrio:: insertarVias(Via *v){

  if(conjuntoVias == NULL ){
		conjuntoVias = new ArbolB <Via*, Comparar>;
  }

	conjuntoVias->insertar(v);

}


void Barrio::insertarArboles(int codigoVia, Arbol *a){

	Via *v;

			buscarVia(codigoVia, v);
			v->insertarArboles(a);
}


// metodo privado
void Barrio::Calles(ArbolB<Via*, Comparar> *conjuntoVias, string especie, ListaPI<Nodo*> *&lista, bool &enc){

	ArbolB<Via*, Comparar> *aux;
	Via *v;

			aux = conjuntoVias->hijoIzq();
			if(aux != NULL)
			 Calles(aux, especie, lista, enc);

			v = conjuntoVias->raiz();
			if(!v->estaVacia())
			  v->Especies(especie, lista, enc);

		  aux = conjuntoVias->hijoDer();
			if(aux !=NULL)
			  Calles(aux, especie, lista, enc);
}

// metodo publico
void Barrio::Calles(string especie, ListaPI<Nodo*> *&lista, bool &enc){

	 if(!conjuntoVias->vacio())
		 	Calles(conjuntoVias, especie, lista, enc);
}


// metodo privado
void Barrio::SubArbol(ArbolB<Via*, Comparar> *conjuntoVias, ArbolB<Via*, Comparar> *&viasgenero, string genero){

	ArbolB<Via*, Comparar> *aux;
	Via *v;
	bool enc;

			aux = conjuntoVias->hijoIzq();
			if(aux != NULL){
			 SubArbol(aux, viasgenero, genero);
			}

			v = conjuntoVias->raiz();
			if(!v->estaVacia()){
				enc = v->BuscarArbol(genero);
				if(enc){
					viasgenero->insertar(v);//si encuentra me inserta la via en mi SubArbol
				}
			}

			aux = conjuntoVias->hijoDer();
			if(aux !=NULL){
				SubArbol(aux, viasgenero, genero);
			}

}

// metodo publico
void Barrio::SubArbol(ArbolB<Via*, Comparar> *&viasgenero, string genero){

	if(!conjuntoVias->vacio()){
		 SubArbol(conjuntoVias, viasgenero, genero);
	}

}

// metodo privado
void Barrio::BuscarSubCadena(ArbolB <Via*, Comparar> *conjuntoVias, string subCadena, ofstream &flujoSubcadena, bool &enc){

	ArbolB<Via*, Comparar> *aux;
	Via *v;
	int arboles = 20;

			aux = conjuntoVias->hijoIzq();
			if(aux != NULL)
			 BuscarSubCadena(aux, subCadena, flujoSubcadena,enc);

			v = conjuntoVias->raiz();
			if(!v->estaVacia())
				if(v->getNombreVia().find(subCadena) == 0){
					flujoSubcadena << v->getNombreVia();
					for (int i = 0; i < (40 - v->getNombreVia().length()); i++)
			      flujoSubcadena << " ";
					flujoSubcadena << v->numeroArboles();
					if(v->numeroArboles() < 10)
						arboles+=2;
					else if(v->numeroArboles() < 100)
					 	arboles++;
					for (int i = 0; i < arboles; i++)
						flujoSubcadena << " ";

					flujoSubcadena << this->getNombre() << endl;
				}

		  aux = conjuntoVias->hijoDer();
			if(aux !=NULL)
			  BuscarSubCadena(aux, subCadena, flujoSubcadena, enc);

}

// metodo publico
void Barrio::subCadena(string subCadena, ofstream &flujoSubcadena, bool &enc){

		if(!conjuntoVias->vacio()){
			if(this->getNombre().find(subCadena) == 0){
				enc = true;
				BuscarSubCadena(conjuntoVias, subCadena, flujoSubcadena, enc);
			}
		}
	}
