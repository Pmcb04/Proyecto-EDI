/*
 * Arbol.h
 *
 *  Created on: 11 ab. 2019
 *      Authors:  - Pedro Miguel Carmona Broncano
 *							  - Ruben Marin Lucas
 */



#ifndef ARBOL_H_
#define ARBOL_H_
#include <string>
#include <iostream>
#include "cola.h"
using namespace std;

class Arbol {

  string especie;
  string familia;
  string nombreComun;
  string genero;
  string riego;
  float diametro;
  float altura;
  float copa;
  int unidades;
  int codigoVia;

public:

  /*
   * PRE: { }
   * POST:{ Constructor por defecto }
   * COMPLEJIDAD:O(1)
   */
  Arbol();

  /*
   * PRE: { }
   * POST:{ Construye el arbol con los parametros introducidos }
   * COMPLEJIDAD:O(1)
   */
  Arbol(string especie, string familia, string nombreComun, string genero, float diametro,
        float altura, float copa, string riego, int unidades, int codigoVia);

 /*
  * PRE: { La variable "especie" inicializada correctamente }
  * POST:{ Introduce el contenido de la
  *       variable "especie" en el atributo -especie- }
  * COMPLEJIDAD:O(1)
  */
  void setEspecie(string especie);

  /*
   * PRE: { La variable "familia" inicializada correctamente }
   * POST:{ Introduce el contenido de la
   *       variable "familia" en el atributo -familia- }
   * COMPLEJIDAD:O(1)
   */
  void setFamilia(string familia);

  /*
   * PRE: { La variable "nombreComun" inicializada correctamente }
   * POST:{ Introduce el contenido de la
   *       variable "nombreComun" en el atributo -nombreComun- }
   * COMPLEJIDAD:O(1)
   */
  void setNombreComun(string nombreComun);

  /*
   * PRE: { La variable "genero" inicializada correctamente }
   * POST:{ Introduce el contenido de la
   *       variable "genero" en el atributo -genero- }
   * COMPLEJIDAD:O(1)
   */
  void setGenero(string genero);

  /*
   * PRE: { La variable "riego" inicializada correctamente }
   * POST:{ Introduce el contenido de la
   *       variable "riego" en el atributo -rdiametro
   * COMPLEJIDAD:O(1)
   */
  void setRiego(string riego);

  /*
   * PRE: { La variable "diametro" inicializada correctamente }
   * POST:{ Introduce el contenido de la
   *       variable "diametro" en el atributo -diametro- }
   * COMPLEJIDAD:O(1)
   */
  void setDiametro(float diametro);

  /*
   * PRE: { La variable "altura" inicializada correctamente }
   * POST:{ Introduce el contenido de la
   *       variable "altura" en el atributo -altura- }
   * COMPLEJIDAD:O(1)
   */
  void setAltura(float altura);

  /*
   * PRE: { La variable "copa" inicializada correctamente }
   * POST:{ Introduce el contenido de la
   *       variable "copa" en el atributo -copa- }
   * COMPLEJIDAD:O(1)
   */
  void setCopa(float copa);

  /*
   * PRE: { La variable "unidades" inicializada correctamente }
   * POST:{ Introduce el contenido de la
   *       variable "unidades" en el atributo -unidades- }
   * COMPLEJIDAD:O(1)
   */
  void setUnidades(int unidades);

  /*
   * PRE: { La variable "codigoVia" inicializada correctamente }
   * POST:{ Introduce el contenido de la
   *       variable "codigoVia" en el atributo -codigoVia- }
   * COMPLEJIDAD:O(1)
   */
  void setCodigoVia(int codigoVia);

  /*
	 * PRE: { El arbol debe tener el atributo -especie- inicializado }
	 * POST:{ Devuelve el contenido del atributo -especie- }
	 * COMPLEJIDAD:O(1)
	 */
  string getEspecie();

  /*
	 * PRE: { El arbol debe tener el atributo -setFamilia- inicializado }
	 * POST:{ Devuelve el contenido del atributo -setFamilia- }
	 * COMPLEJIDAD:O(1)
	 */
  string getFamilia();

  /*
	 * PRE: { El arbol debe tener el atributo -nombreComun- inicializado }
	 * POST:{ Devuelve el contenido del atributo -nombreComun- }
	 * COMPLEJIDAD:O(1)
	 */
  string getNombreComun();

  /*
	 * PRE: { El arbol debe tener el atributo -genero- inicializado }
	 * POST:{ Devuelve el contenido del atributo -genero- }
	 * COMPLEJIDAD:O(1)
	 */
  string getGenero();

  /*
	 * PRE: { El arbol debe tener el atributo -riego- inicializado }
	 * POST:{ Devuelve el contenido del atributo -riego- }
	 * COMPLEJIDAD:O(1)
	 */
  string getRiego();

  /*
	 * PRE: { El arbol debe tener el atributo -diametro- inicializado }
	 * POST:{ Devuelve el contenido del atributo -diametro- }
	 * COMPLEJIDAD:O(1)
	 */
  float getDiametro();

  /*
	 * PRE: { El arbol debe tener el atributo -altura- inicializado }
	 * POST:{ Devuelve el contenido del atributo -altura- }
	 * COMPLEJIDAD:O(1)
	 */
  float getAltura();

  /*
	 * PRE: { El arbol debe tener el atributo -copa- inicializado }
	 * POST:{ Devuelve el contenido del atributo -copa- }
	 * COMPLEJIDAD:O(1)
	 */
  float getCopa();

  /*
	 * PRE: { El arbol debe tener el atributo -unidades- inicializado }
	 * POST:{ Devuelve el contenido del atributo -unidades- }
	 * COMPLEJIDAD:O(1)
	 */
  int getUnidades();

  /*
	 * PRE: { El arbol debe tener el atributo -codigoVia- inicializado }
	 * POST:{ Devuelve el contenido del atributo -codigoVia- }
	 * COMPLEJIDAD:O(1)
	 */
  int getCodigoVia();

  /*
   * PRE: {}
   * POST:{ Constructor por defecto }
   * COMPLEJIDAD:O(1)
   */
  void mostrar();

  /*
	 * PRE: { El arbol debe estar inicializado }
	 * POST:{ Muestra por pantalla la información del arbol }
	 * COMPLEJIDAD:O(1)
	 */
	~Arbol();

};

#endif /* ARBOL_H_ */
