/*
 * pruebasBarrios.cpp
 *
 *  Created on: 18 feb. 2019
 *      Authors:  - Pedro Miguel Carmona Broncano
 									- Ruben Marin Lucas
 */

#include "pruebasBarrios.h"

const float ERROR = 0.01;

void pruebasBarrios(){


cout << "-------------INICIO PRUEBA BARRIOS--------------" << endl;
pruebasPorDefectoB();
pruebasParametrizadoB();
pruebasSetGetB();
pruebasBuscarViasB();
pruebasInsertarViasB();
pruebasEstaVacioB();

cout << "-------------FIN PRUEBA BARRIOS-----------------" << endl;

}

void pruebasEstaVacioB(){

	cout << "-------------INICIO PRUEBA ESTA VACIO-----------------" << endl;

	Barrio *b;
	Via *v;

	// creamos un barrio
	b = new Barrio();

  // ahora vemos si el barrio está vacio
	if(!b->estaVacio())
		cout << "ERROR fallo en esta vacio (Prueba 1)" << endl;

 // creamos una nueva via
	v = new Via();

 // insertamos la via v en el barrio b
	b->insertarVias(v);

 // comprobamos que una vez insertada la via v el barrio b, ya no se encuentra vacio
	if(b->estaVacio())
	  cout << "ERROR fallo en esta vacio (Prueba 2)" << endl;

	delete b;

	cout << "-------------FIN PRUEBA ESTA VACIO-----------------" << endl;


}

void pruebasInsertarViasB(){

cout << "-------------INICIO PRUEBA INSERTAR VIAS --------------" << endl;


	Barrio *b; // contendrá vias && arboles ("Virgen de la montaña")

	/*********** Barrio Virgen De La Montaña **********
		69 centro 47936.6 1015.9*/
	b = new Barrio("Virgen de la montaña", 47936.64, 1015.9, 69, "centro");

	Via *v31, *v32; // Vias del barrio b3

	/*********** Via Carreteros **********
		011169 	Calle 	32.79 */
	v31 = new Via (69, "Carreteros", 32.79, "Calle", 0111);

	/*	********** Via Aperadores **********
		005069 	Calle 	43.57*/
	v32 = new Via (69, "Aperadores", 43.57, "Calle", 0050);

	cout << "-------------INICIO INSERCION V31 --------------" << endl;

	// insertamos la via v31
	b->insertarVias(v31);

	// mostramos para asegurar de que se a insertado la via v31
	b->mostrar();

	cout << "-------------FIN INSERCION V31 --------------" << endl;
	cout << "-------------INICIO INSERCION V32 --------------" << endl;

	// insertamos la via v32
	b->insertarVias(v32);

	// mostramos para asegurar de que se a insertado la via v32
	b->mostrar();

	cout << "-------------FIN INSERCION V32 --------------" << endl;
	cout << "-------------FIN PRUEBA INSERTAR VIAS --------------" << endl;

	delete b;
}

void pruebasPorDefectoB(){

	cout << "-------------INICIO PRUEBA BARRIOS CONSTRUCTOR POR DEFECTO --------------" << endl;

	Barrio *b;

	// 1º PRUEBA (CONSTRUCTOR POR DEFECTO)

	b = new Barrio();

	if(b->getNombre() != "")
		cout << "ERROR en atributo nombre (metodo)(constructor por defecto)" << endl;

	if(b->getDistrito() != "")
		cout << "ERROR en atributo nombreDistrito (constructor por defecto)" << endl;

	if(b->getArea() > (0.0 + ERROR))
		cout << "ERROR en atributo area (constructor por defecto)" << endl;

	if(b->getPerimetro() > (0.0 + ERROR))
		cout << "ERROR en atributo perimetro (constructor por defecto)" << endl;

	if(b->getCodigo() != 0)
		cout << "ERROR en atributo codigo (constructor por defecto)" << endl;

	if(!b->estaVacio())
		cout << "ERROR en atributo conjuntoVias (constructor por defecto)" << endl;

	delete b;

		cout << "-------------FIN PRUEBA BARRIOS CONSTRUCTOR POR DEFECTO --------------" << endl;
}

void pruebasParametrizadoB(){

	cout << "-------------INICIO PRUEBA BARRIOS CONSTRUCTOR PARAMETRIZADO --------------" << endl;

	Barrio *b;

	// 2º PRUEBA (CONSTRUCTOR PARAMETRIZADO)

	b = new Barrio("La Cañada",109035.09,1782.1,77,"sur");

	if(b->getNombre() != "La Cañada")
		cout << "ERROR en atributo nombre (metodo)(constructor parametrizado)" << endl;

	if(b->getDistrito() != "sur")
		cout << "ERROR en atributo nombreDistrito (constructor parametrizado)" << endl;

	if(b->getArea() > (109035.09 + ERROR))
		cout << "ERROR en atributo area (constructor parametrizado)" << endl;

	if(b->getPerimetro() > (1782.1 + ERROR))
		cout << "ERROR en atributo perimetro (constructor parametrizado)" << endl;

	if(b->getCodigo() != 77)
		cout << "ERROR en atributo codigo (constructor parametrizado)" << endl;

	if(!b->estaVacio())
		cout << "ERROR en atributo conjuntoVias (constructor parametrizado)" << endl;

	delete b;

		cout << "-------------FIN PRUEBA BARRIOS CONSTRUCTOR PARAMETRIZADO --------------" << endl;
}

void pruebasSetGetB(){

	cout << "-------------INICIO PRUEBA BARRIOS SET / GET --------------" << endl;

	Barrio *b;

	//3º PRUEBA METODOS SET/GET

	b = new Barrio();

		b->setNombre("Campus Universitario");
		b->setDistrito("norte");
		b->setArea(1504384.69);
		b->setPerimetro(6002.54);
		b->setCodigo(46);

		if(b->getNombre() != "Campus Universitario")
			cout << "ERROR en atributo nombre (metodo)(SET/GET)" << endl;

		if(b->getDistrito() != "norte")
			cout << "ERROR en atributo nombreDistrito (SET/GET)" << endl;

		if(b->getArea() < (1504384.69 + ERROR))
			cout << "ERROR en atributo area (SET/GET)" << endl;

		if(b->getPerimetro() > (6002.54 + ERROR))
			cout << "ERROR en atributo perimetro (SET/GET)" << endl;

		if(b->getCodigo() != 46)
			cout << "ERROR en atributo codigo (SET/GET)" << endl;

		if(!b->estaVacio())
			cout << "ERROR en atributo conjuntoVias (SET/GET)" << endl;

		delete b;

			cout << "-------------FIN PRUEBA BARRIOS SET / GET --------------" << endl;
}

void pruebasBuscarViasB(){

		cout << "--------------- INICIO BUSCAR VIAS ---------------" << endl;

	Barrio *b2; // contendrá vias, pero no arboles ("El Junquillo")
	Barrio *b3; // contendrá vias && arboles ("Virgen de la montaña")

	Via *v21, *v22; // Vias del barrio b2
	Via *v31, *v32; // Vias del barrio b3
	Via *v; // Via aux

	/*********** Barrio El Junquillo **********
	49 oeste 311396 2248.77*/
	b2 = new Barrio("El Junquillo", 311396.34, 2248.77, 49, "oeste");

	/*********** Barrio Virgen De La Montaña **********
	69 centro 47936.6 1015.9*/
	b3 = new Barrio("Virgen de la montaña", 47936.64, 1015.9, 69, "centro");

	/*********** Via Amapola **********
		346249 	Calle 	619.56*/
	v21 = new Via (49, "Amapola", 619.56, "Calle", 3462);

	/*********** Via Clavel **********
		346449 	Calle 	396.79*/
	v22 = new Via (49, "Clavel", 396.79, "Calle", 3464);

	/*********** Via Carreteros **********
		011169 	Calle 	32.79 */
	v31 = new Via (69, "Carreteros", 32.79, "Calle", 0111);

	/*	********** Via Aperadores **********
		005069 	Calle 	43.57*/
	v32 = new Via (69, "Aperadores", 43.57, "Calle", 0050);


	// vemos que la el barrio b2 no tiene ninguna via
	if(!b2->estaVacio())
		cout << "ERROR El conjunto de vias de b2 no esta vacio" << endl;

	// cargamos las vias correspondientes a b2
	b2->insertarVias(v21);
	b2->insertarVias(v22);

	// y ahora vemos que se han insertado las vias
	if(b2->estaVacio())
		cout << "ERROR El conjunto de vias de b2 esta vacio" << endl;

	// vemos que la el barrio b3 no tiene ninguna via
	if(!b3->estaVacio())
		cout << "ERROR El conjunto de vias de b3 no esta vacio" << endl;

	//cargamos las vias correspondientes a b3
	b3->insertarVias(v31);
	b3->insertarVias(v32);

	// y ahora vemos que se han insertado las vias
	if(b3->estaVacio())
		cout << "ERROR El conjunto de vias de b3 esta vacio" << endl;


 // ------------------1º BARRIO -----------------------------------

 // buscamos por codigo de via la via Amapola
 if(!b2->buscarVia(3462 , v))
 cout << "ERROR en buscar via de b (El Junquillo)" << endl;

 // comprobamos que nos ha devuelto esa via
 if(v->getNombreVia() != "Amapola")
 cout << "ERROR en buscar via de b (El Junquillo)" << endl;

 // ---------------------------- 2º BARRIO ------------------------------------

// buscamos por codigo de via la via Carreteros
if(!b3->buscarVia(0111 , v))
	cout << "ERROR en buscar via de b (Virgen de la montaña)" << endl;

// comprobamos que nos ha devuelto esa via
if(v->getNombreVia() != "Carreteros")
	cout << "ERROR en buscar via de b (Virgen de la montaña)" << endl;

delete b2;
delete b3;

 cout << "--------------- FIN BUSCAR VIAS ---------------" << endl;
}
