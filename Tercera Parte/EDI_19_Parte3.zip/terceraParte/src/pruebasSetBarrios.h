/*
 * pruebasSetBarrios.h
 *
 *  Created on: 18 feb. 2019
 *      Authors:  - Pedro Miguel Carmona Broncano
 									- Ruben Marin Lucas
 */

#ifndef PRUEBASETBARRIOS_H_
#define PRUEBASETBARRIOS_H_

#include "SetBarrios.h"


/*Se comprueba el insetado creando un cjtoBarrios y un barrio
 e insertando en el conjunto este ultimo*/
void pruebasInsertar();

/*Se crea un cjtoBarrios y se instroducen un nº de barrios
para comprobar que el numero de elementos del conjunto es el deseado*/
void pruebasNumeroElementos();

/*Se crea un cjtoBarrios y se introducen un nº de barrios para despues
borralos uno a uno, comprobando en cada borrado que el numero de elementos
a decrementado en uno*/
void pruebasBorrado();

/*Se crea un cjtoBarrios y se introducen un nº de barrios para despues
comprobar que existen en el conjunto*/
void pruebasExistebarrio();

/*Se crea un cjtoBarrios y se comprueba que esta vacio comprobando
que el nº de elementos es 0, posteriormente se crea un barrio y se
introduce en el conjunto para comprobar que el numero de
elementos a incrementado en uno, esto quiere decir que el conjunto
ya no se encuentra vacio */
void pruebasEstaVacio();


/*Se crea un cjtobarrio y se introduce un nº de Barrios para
despues comprobar que se han introducido con getBarrio*/
void pruebasGetBarrio();

// llamada a todos los modulos de prueba de esta clase
void pruebasSetBarrios();


#endif /* PRUEBASETBARRIOS_H_ */
