/*
 * Barrio.h
 *
 *  Created on: 18 feb. 2019
 *       Authors:  - Pedro Miguel Carmona Broncano
 *							   - Ruben Marin Lucas
 */



#ifndef BARRIO_H_
#define BARRIO_H_

#include <string>
#include "listapi.h"
#include "Via.h"
#include <iostream>
#include "ArbolB.h"
#include <iomanip>////-----
using namespace std;


class Comparar{
public:
	int operator() (Via *v1, Via * v2){
		int result;
		if (v1->getNombreVia() == v2->getNombreVia())
			result = 0;
		else if (v1->getNombreVia() > v2->getNombreVia())
			result = 1;
					else result = -1;
		return result;
	}
};

class Barrio {

	string nombre;
	string nombreDistrito;
	float area;
	float perimetro;
	int codigo;
	ArbolB <Via*, Comparar> *conjuntoVias;

	/*
	* PRE: { La variable "nombreVia", el puntero "v" y -conjuntoVias- inicializado correctamente }
	* POST:{ Devuelve true en caso de encontrar una via con un cierto codigo de via y false en
	*        caso contrario }
	* COMPLEJIDAD:O(n)
	*/
	bool buscarVia(ArbolB<Via*, Comparar> *conjuntoVias, int codigoVia, Via *&v);

	/*
	* PRE: { La variable "nombreVia", el puntero "v" y -conjuntoVias- inicializado correctamente }
	* POST:{ Devuelve true en caso de encontrar una via con un cierto nombre y false en caso contrario }
	* COMPLEJIDAD:O(log(n))
	*/
  bool buscarVia(ArbolB<Via*, Comparar> *conjuntoVias, string nombreVia, Via *&v);

	/*
  * PRE: { -conjuntoVias- inicializado correctamente }
  * POST:{ Muestra la informacion del barrio }
  * COMPLEJIDAD:O(n²)
  */
	void mostrarinOrden(ArbolB<Via*, Comparar> *conjuntoVias);

	/*
	* PRE: { El puntero "lista", la variable "especie" y -conjuntoVias- inicializado correctamente }
	* POST:{ Devuelve un puntero hacia una lista con las vias que contienen arboles
	*        de una determinada especie, ademas en caso de encontrar lo deseado devolvera
	*        true, en caso de no encontrar ningun arbol de esa especie en esa via devolvera
	*        false }
	* COMPLEJIDAD:O(n²)
	*/
  void Calles(ArbolB<Via*, Comparar> *conjuntoVias, string especie, ListaPI<Nodo*> *&lista, bool &enc);

	/*
	* PRE: { El puntero "vias", la variable "genero" y  -conjuntoVias- inicializado correctamente }
	* POST:{ Devuelve un puntero hacia un arbol con las vias que contienen arboles
	*        de un determinado genero }
	* COMPLEJIDAD:O(n²)
	*/
  void SubArbol(ArbolB<Via*, Comparar> *conjuntoVias, ArbolB<Via*, Comparar> *&vias, string genero);

	/*
	* PRE: { El flujo "flujoSubcadena", la variable "subCadena" y -conjuntoVias- inicializado correctamente }
	* POST:{ Escribe en un fichero con flujo "flujoSubcadena" las vias cuyo nombre empiece por una determinada
  *        subcadena }
	* COMPLEJIDAD:O(n²)
	*/
	void BuscarSubCadena (ArbolB <Via*, Comparar> *conjuntoVias, string subCadena, ofstream &flujoSubcadena, bool &enc);

public:

	/*
	 * PRE: {}
	 * POST:{ Constructor por defecto }
	 * COMPLEJIDAD:O(1)
	 */
	Barrio();

	/*
	 * PRE: { }
	 * POST:{ Construye el barrio con los parametros introducidos }
	 * COMPLEJIDAD:O(1)
	 */
	Barrio(string nombre, float area, float perimetro, int codigo, string distrito);


	/*
	 * PRE: {}
	 * POST:{ Destructor por defecto }
	 * COMPLEJIDAD:O(n²)
	 */
	~Barrio();

	//metodos settter


	/*
	 * PRE: { La variable "nombre" inicializada correctamente }
	 * POST:{ Introduce el contenido de la
	 *       variable "nombre" en el atributo -nombre- }
	 * COMPLEJIDAD:O(1)
	 */
	void setNombre(string nombre);

	/*
	 * PRE: { La variable "area" inicializada correctamente }
	 * POST:{ Introduce el contenido de la
	 *       variable "area" en el atributo -area- }
	 * COMPLEJIDAD:O(1)
	 */
	void setArea(float area);

	/*
	 * PRE: { La variable "perimetro" inicializada correctamente }
	 * POST:{ Introduce el contenido de la
	 *       variable "perimetro" en el atributo -perimetro- }
	 * COMPLEJIDAD:O(1)
	 */
	void setPerimetro(float perimetro);

	/*
	 * PRE: { La variable "distrito" inicializada correctamente }
	 * POST:{ Introduce el contenido de la
	 *       variable "distrito" en el atributo -distrito- }
	 * COMPLEJIDAD:O(1)
	 */
	void setDistrito(string distrito);

	/*
	 * PRE: { La variable "codigo" inicializada correctamente }
	 * POST:{ Introduce el contenido de la
	 *       variable "codigo" en el atributo -codigo- }
	 * COMPLEJIDAD:O(1)
	 */
	void setCodigo(int codigo);

	/*
	 * PRE: {El barrio debe estar inicializado}
	 * POST:{ Muestra por pantalla la información del barrio y la
	 					de todas sus vias }
	 * COMPLEJIDAD:O(1)
	 */

	void mostrar();


	//Metodos Getter

	/*
	 * PRE: { El barrio debe tener el atributo -nombre- inicializado }
	 * POST:{ Devuelve el contenido del atributo -nombre- }
	 * COMPLEJIDAD:O(1)
	 */
	string getNombre();

	/*
	 * PRE: {}
	 * POST:{ Devuelve true si el -conjuntoVias- esta vacia y false en caso contrario }
	 * COMPLEJIDAD:O(1)
	 */
	bool estaVacio();

	/*
	 * PRE: { El barrio debe tener el atributo -area- inicializado }
	 * POST:{ Devuelve el contenido del atributo -area- }
	 * COMPLEJIDAD:O(1)
	 */
	float getArea();

	/*
	 * PRE: { El barrio debe tener el atributo -perimetro- inicializado }
	 * POST:{ Devuelve el contenido del atributo -perimetro- }
	 * COMPLEJIDAD:O(1)
	 */
	float getPerimetro();

	/*
	 * PRE: { El barrio debe tener el atributo -codigo- inicializado }
	 * POST:{ Devuelve el contenido del atributo -codigo- }
	 * COMPLEJIDAD:O(1)
	 */
	int getCodigo();

 /*
	* PRE: { El barrio debe tener el atributo -nombreDistrito- inicializado }
	* POST:{ Devuelve el contenido del atributo -nombredistrito- }
	* COMPLEJIDAD:O(1)
	*/
	string getDistrito();

 /*
	* PRE: { La variable "nombre" y el puntero "via" deben estar incializados,
  *        el atributo -conjuntoVias- no puede estar vacio, es decir, conjuntoVias != NULL }
	* POST:{ Devuelve true en el caso de encontrar la via especificada y false en caso contrario }
	* COMPLEJIDAD:O(log(n))
	*/
	bool buscarVia(string nombre, Via *&v);

 /*
	* PRE: { La variable "codigoVia" y el puntero "via" deben estar inicializados,
	*        el atributo -conjuntoVias- no puede estar vacio, es decir, conjuntoVias != NULL }
	* POST:{ Devuelve true en el caso de encontrar la via especificada y false en caso contrario }
	* COMPLEJIDAD:O(n)
	*/
	bool buscarVia(int codigoVia, Via *&v);

 /*
	* PRE: { El puntero "v" incializado correctamente }
	* POST:{ Inserta la via a la que esta apuntado "v" en -conjuntoVias- }
	* COMPLEJIDAD:O(1)
	*/
	void insertarVias(Via *v);

	/*
 	* PRE: { La variable "codigoVia" y el puntero "a" incializados correctamente}
 	* POST:{ Inserta el arbol al que esta apuntado "a" en -conjuntoArboles-
  *        de la via la cual su -codigoVia- coincide con el contenido de
  *        la variable "codigoVia" }
 	* COMPLEJIDAD:O(n)
 	*/
	void insertarArboles(int codigoVia, Arbol *a);

	/*
	* PRE: { El puntero "lista"  y la variable "especie" inicializado correctamente }
	* POST:{ Devuelve un puntero hacia una lista con las vias que contienen arboles
  *        de una determinada especie, ademas en caso de encontrar lo deseado devolvera
  *        true, en caso de no encontrar ningun arbol de esa especie en esa via devolvera
  *        false }
	* COMPLEJIDAD:O(n²)
	*/
	void Calles(string especie, ListaPI<Nodo*> *&lista, bool &enc);

	/*
	* PRE: { El puntero "vias" y la variable "genero" inicializados correctamente }
	* POST:{ Devuelve un puntero hacia un arbol con las vias que contienen arboles
	*        de un determinado genero }
	* COMPLEJIDAD:O(n²)
	*/
	void SubArbol(ArbolB<Via*, Comparar> *&vias, string genero);

	/*
	* PRE: { El flujo "flujoSubcadena" y la variable "subCadena" inicializados correctamente }
	* POST:{ Comprueba que el nombre del barrio comienza por la subcadena "subCadena", en caso
  *        de que el nombre del barrio empice por dicha subcadena actualiza el bool "enc" a true }
	* COMPLEJIDAD:O(n²)
	*/
	void subCadena(string subCadena, ofstream &flujoSubcadena, bool &enc);

};

#endif /* BARRIO_H_ */
