/*
 * pruebasArboles.h
 *
 *  Created on: 18 feb. 2019
 *      Authors:  - Pedro Miguel Carmona Broncano
 									- Ruben Marin Lucas
 */

#ifndef PRUEBASARBOLES_H_
#define PRUEBASARBOLES_H_

#include "Arbol.h"

/*Se crea un arbol por constructor por defecto y
se comprueba , que todos los parametros se inician correctamente*/
void pruebasPorDefectoA();

/*Se crea un arbol por constructor parametrizado y
se comprueba, que todos los parametros se inician correctamente */
void pruebasParametrizadoA();

/*Se crea un arbol por constructor por defecto y
se introducen los parametros por los metodos set y se comprueban de que
todos los parametros se inician correctamente*/
void pruebasSetGetA();

// llamada a todos los modulos de prueba de esta clase
void pruebasArboles();


#endif /* PRUEBASARBOLES_H_ */
