/*
 * pruebasSetBarrios.cpp
 *
 *  Created on: 18 feb. 2019
 *      Authors:  - Pedro Miguel Carmona Broncano
 									- Ruben Marin Lucas
 */

#include "pruebasSetBarrios.h"

const float ERROR = 0.01;


void pruebasSetBarrios(){

		cout << "--------------- INICIO PRUEBA SETBARRIOS ---------------" << endl;

		pruebasInsertar();
	  pruebasNumeroElementos();
	  pruebasBorrado();
	  pruebasExistebarrio();
		pruebasEstaVacio();
		pruebasGetBarrio();

	cout << "--------------- FIN PRUEBA SETBARRIOS ---------------" << endl;

}

void pruebasEstaVacio(){

		cout << "--------------- INICIO PRUEBA ESTA VACIO ---------------" << endl;

	SetBarrios *cjtoBarrios = new SetBarrios();

	if(cjtoBarrios->numElementos() != 0)
		cout << "ERROR cjtoBarrios no está vacio" << endl;

	Barrio *b = new Barrio ();

	cjtoBarrios->insertarBarrios(b);

	if(cjtoBarrios->numElementos() == 0)
		cout << "ERROR cjtoBarrios está vacio" << endl;

		delete cjtoBarrios;

		cout << "--------------- FIN PRUEBA ESTA VACIO ---------------" << endl;


}

void pruebasGetBarrio(){

	cout << "--------------- INICIO PRUEBA GET BARRIO ---------------" << endl;

	SetBarrios *cjtoBarrios = new SetBarrios();
	Barrio *b1; // no contendrá vias ("Poligono Ganadero")
	Barrio *b2; // contendrá vias, pero no arboles ("El Junquillo")
	Barrio *b3; // contendrá vias && arboles ("Virgen de la montaña")
	Barrio *b; // barrio aux

	/********** Barrio Poligono Ganadero **********
		28 norte 1.08954e+06 6467.69*/
	b1 = new Barrio("Poligono Ganadero", 1089542.02, 6467.69, 28, "norte");

	/*********** Barrio El Junquillo **********
		49 oeste 311396 2248.77*/
	b2 = new Barrio("El Junquillo", 311396.34, 2248.77, 49, "oeste");

	/*********** Barrio Virgen De La Montaña **********
		69 centro 47936.6 1015.9*/
	b3 = new Barrio("Virgen de la montaña", 47936.64, 1015.9, 69, "centro");

	// Insertarmos el b1 en cjtoBarrios
	cjtoBarrios->insertarBarrios(b1);

	// Insertamos el b2 en cjtoBarrios
	cjtoBarrios->insertarBarrios(b2);

	// Insertamos el b3 en cjtoBarrios
	cjtoBarrios->insertarBarrios(b3);

	// Ahora vamos a ver si existen los barrios por su codigo
	cjtoBarrios->getBarrio(28, b);

	if(b->getNombre() != "Poligono Ganadero")
		cout << "ERROR no es Poligono Ganadero" << endl;

	cjtoBarrios->getBarrio(49, b);

	if(b->getNombre() != "El Junquillo")
		cout << "ERROR no es El Junquillo" << endl;

	cjtoBarrios->getBarrio(69, b);

	if(b->getNombre() != "Virgen de la montaña")
		cout << "ERROR no es Virgen de la montaña" << endl;

  // Y ahora por la posicion, ya que el cjtobarrios esta ordenado por nombre

	cjtoBarrios->get(0, b);

	if(b->getNombre() != "El Junquillo")
		cout << "ERROR no es Poligono Ganadero" << endl;

	cjtoBarrios->get(1, b);

	if(b->getNombre() != "Poligono Ganadero")
		cout << "ERROR no es Poligono Ganadero" << endl;

	cjtoBarrios->get(2, b);

	if(b->getNombre() != "Virgen de la montaña")
		cout << "ERROR no es Poligono Ganadero" << endl;

	delete cjtoBarrios;

	cout << "--------------- FIN PRUEBA GET BARRIO ---------------" << endl;

}
void pruebasInsertar(){


		cout << "--------------- INICIO INSERTAR ---------------" << endl;

		SetBarrios *cjtoBarrios = new SetBarrios();
		Barrio *b = new Barrio ();

		// En un principio, cjtoBarrios debe estar vacio
		if(!cjtoBarrios->estaVacia())
			cout << "ERROR cjtoBarrios esta lleno (prueba insertar)" << endl;

		// Insertamos el barrio b
		cjtoBarrios->insertarBarrios(b);

    // Comprobamos que ahora el cjtoBarrios no está vacio por que tiene un elemento (bs)
		if(cjtoBarrios->estaVacia())
			cout << "ERROR cjtoBarrios esta vacio (prueba insertar)" << endl;

		delete cjtoBarrios;

		cout << "--------------- FIN INSERTAR ---------------" << endl;

}

void pruebasNumeroElementos(){

	cout << "--------------- INICIO NUMERO ELEMENTOS ---------------" << endl;

	SetBarrios *cjtoBarrios = new SetBarrios();
	Barrio *b1 = new Barrio ();
	Barrio *b2 = new Barrio ();
	Barrio *b3 = new Barrio ();

	// Insertarmos el b1 en cjtoBarrios
	cjtoBarrios->insertarBarrios(b1);

	// Comprobamos que se a insertado, mirando el nº de elementos del conjunto
	if(cjtoBarrios->numElementos() != 1)
		cout << "ERROR cjtoBarrios nº elem 1 (prueba numero elementos)" << endl;

	// Incnsertamos el b2 en cjtoBarrios
	cjtoBarrios->insertarBarrios(b2);

	// Comprobamos que se a insertado, mirando el nº de elementos del conjunto
	if(cjtoBarrios->numElementos() != 2)
		cout << "ERROR cjtoBarrios nº elem 2 (prueba numero elementos)" << endl;

	// Insertamos el b3 en cjtoBarrios
	cjtoBarrios->insertarBarrios(b3);

  // Comprobamos que se a insertado, mirando el nº de elementos del conjunto
	if(cjtoBarrios->numElementos() != 3)
		cout << "ERROR cjtoBarrios nº elem 3 (prueba numero elementos)" << endl;

	delete cjtoBarrios;

	cout << "--------------- FIN NUMERO ELEMENTO ---------------" << endl;

}

void pruebasBorrado(){

	cout << "--------------- INICIO BORRADO ---------------" << endl;

	SetBarrios *cjtoBarrios = new SetBarrios();
	Barrio *b1 = new Barrio ();
	Barrio *b2 = new Barrio ();
	Barrio *b3 = new Barrio ();

	// Insertarmos el b1 en cjtoBarrios
	cjtoBarrios->insertarBarrios(b1);

	// Insertamos el b2 en cjtoBarrios
	cjtoBarrios->insertarBarrios(b2);

	// Insertamos el b3 en cjtoBarrios
	cjtoBarrios->insertarBarrios(b3);


	// borramos un elemento de cjtoBarrios
	cjtoBarrios->eliminar("");

	// comprobamos que se a borrado satisfactoriamente, mirando el nº de elementos del conjunto
	if(cjtoBarrios->numElementos() != 2)
		cout << "ERROR cjtoBarrios borrado nº1 (prueba borrado)" << endl;

	// borramos un elemento de cjtoBarrios
	cjtoBarrios->eliminar("");

	// comprobamos que se a borrado satisfactoriamente, mirando el nº de elementos del conjunto
	if(cjtoBarrios->numElementos() != 1)
		cout << "ERROR cjtoBarrios borrado nº2 (prueba borrado)" << endl;

	// borramos un elemento de cjtoBarrios
	cjtoBarrios->eliminar("");

  // comprobamos que se a borrado satisfactoriamente, mirando el nº de elementos del conjunto
	if(cjtoBarrios->numElementos() != 0)
		cout << "ERROR cjtoBarrios borrado nº3 (prueba borrado)" << endl;

	delete cjtoBarrios;

	cout << "--------------- FIN BORRADO ---------------" << endl;

}

void pruebasExistebarrio(){

	cout << "--------------- INICIO EXISTE BARRIO ---------------" << endl;

	SetBarrios *cjtoBarrios = new SetBarrios();
	Barrio *b1; // no contendrá vias ("Poligono Ganadero")
	Barrio *b2; // contendrá vias, pero no arboles ("El Junquillo")
	Barrio *b3; // contendrá vias && arboles ("Virgen de la montaña")

	/********** Barrio Poligono Ganadero **********
		28 norte 1.08954e+06 6467.69*/
	b1 = new Barrio("Poligono Ganadero", 1089542.02, 6467.69, 28, "norte");

	/*********** Barrio El Junquillo **********
		49 oeste 311396 2248.77*/
	b2 = new Barrio("El Junquillo", 311396.34, 2248.77, 49, "oeste");

	/*********** Barrio Virgen De La Montaña **********
		69 centro 47936.6 1015.9*/
	b3 = new Barrio("Virgen de la montaña", 47936.64, 1015.9, 69, "centro");

	// Insertarmos el b1 en cjtoBarrios
	cjtoBarrios->insertarBarrios(b1);

	// Insertamos el b2 en cjtoBarrios
	cjtoBarrios->insertarBarrios(b2);

	// Insertamos el b3 en cjtoBarrios
	cjtoBarrios->insertarBarrios(b3);

	// Ahora vamos a ver si existen los barrios por su codigo
	if(!cjtoBarrios->existeBarrio(28))
		cout << "ERROR no existe barrio con codigo 28" << endl;

	if(!cjtoBarrios->existeBarrio(49))
		cout << "ERROR no existe barrio con codigo 49" << endl;

	if(!cjtoBarrios->existeBarrio(69))
		cout << "ERROR no existe barrio con codigo 69" << endl;

  // Y ahora por el nombre
	if(!cjtoBarrios->existeBarrio("Poligono Ganadero"))
		cout << "ERROR no existe barrio (Poligono Ganadero)" << endl;

	if(!cjtoBarrios->existeBarrio("El Junquillo"))
		cout << "ERROR no existe barrio (El Junquillo)" << endl;

	if(!cjtoBarrios->existeBarrio("Virgen de la montaña"))
		cout << "ERROR no existe barrio (Virgen de la montaña)" << endl;

	delete cjtoBarrios;

	cout << "--------------- FIN EXISTE BARRRIO ---------------" << endl;

}
