/*
 * Arbol.cpp
 *
 *  Created on: 11 ab. 2019
 *      Authors:  - Pedro Miguel Carmona Broncano
 									- Ruben Marin Lucas
 */

#include "Arbol.h"

Arbol::Arbol(){

  especie = "";
  familia = "";
  nombreComun = "";
  genero = "";
  riego = "";
  diametro = 0.0;
  altura = 0.0;
  copa = 0.0;
  unidades = 0;
  codigoVia = 0;

}

Arbol::Arbol(string especie, string familia, string nombreComun, string genero, float diametro,
      float altura, float copa, string riego, int unidades, int codigoVia){

        this->especie = especie;
        this->familia = familia;
        this->nombreComun = nombreComun;
        this->genero = genero;
        this->riego = riego;
        this->diametro = diametro;
        this->altura = altura;
        this->copa = copa;
        this->unidades = unidades;
        this->codigoVia = codigoVia;

}
Arbol::~Arbol(){


}

void Arbol::setEspecie(string especie){

  this->especie = especie;
}

void Arbol::setFamilia(string familia){

  this->familia = familia;
}
void Arbol::setNombreComun(string nombreComun){

  this->nombreComun = nombreComun;
}
void Arbol::setGenero(string genero){

  this->genero = genero;
}
void Arbol::setRiego(string riego){

  this->riego = riego;
}
void Arbol::setDiametro(float diametro){

  this->diametro = diametro;
}
void Arbol::setAltura(float altura){

  this->altura = altura;
}
void Arbol::setCopa(float copa){

  this->copa = copa;
}
void Arbol::setUnidades(int unidades){

  this->unidades = unidades;
}
void Arbol::setCodigoVia(int codigoVia){

  this->codigoVia = codigoVia;
}
string Arbol::getEspecie(){
  return especie;
}
string Arbol::getFamilia(){
  return familia;
}
string Arbol::getNombreComun(){
  return nombreComun;
}
string Arbol::getGenero(){
  return genero;
}
string Arbol::getRiego(){
  return riego;
}
float Arbol::getDiametro(){
  return diametro;
}
float Arbol::getAltura(){
  return altura;
}
float Arbol::getCopa(){
  return copa;
}
int Arbol::getUnidades(){
  return unidades;
}
int Arbol::getCodigoVia(){
  return codigoVia;
}

void Arbol::mostrar(){

  cout << this->getCodigoVia();
  cout << " ";
  cout << this->getEspecie();
  cout << " ";
  cout << this->getFamilia();
  cout << " ";
  cout << this->getNombreComun();
  cout << " ";
  cout << this->getGenero();
  cout << " ";
  cout << this->getRiego();
  cout << " ";
  cout << this->getDiametro();
  cout << " ";
  cout << this->getAltura();
  cout << " ";
  cout << this->getCopa();
  cout << " ";
  cout << this->getUnidades();
  cout << endl;

}
