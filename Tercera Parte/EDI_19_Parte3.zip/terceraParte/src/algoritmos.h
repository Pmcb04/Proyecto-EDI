/*
 * Algoritmos.h
 *
 *  Created on: 03/03/2019
 *      Author: Profesores de EDI
 */

#ifndef ALGORITMOS_H_
#define ALGORITMOS_H_

#include "SetBarrios.h"
#include "listapi.h"
#include "Via.h"
#include "Arbol.h"

class Algoritmos {

private:

	SetBarrios *cjtoBarrios;

	// carga los datos desde los ficheros de texto
	void cargarDatos();
  // ejecuta todos los algoritmos del proyecto
  void run ();
	/*
	 * PRE: { puntero "vias" correctamente inicializado }
	 * POST:{ muestra los datos que contiene el árbol al que apunta "vias" }
	 * COMPLEJIDAD:O(n)
	 */
	void mostrarinOrden(ArbolB<Via*, Comparar> *vias);

public:


	/*
	 * PRE: { }
	 * POST:{ Constructor por defecto }
	 * COMPLEJIDAD:O(1)
	 */
	 Algoritmos();

	 /*
		* PRE: { cjtoBarrios inicializado }
		* POST:{ muestra todos los datos que se encuentran en cjtoBarrios }
		* COMPLEJIDAD:O(n³)
		*/
	 void mostrarDatos();

	 void ficheroDatos();

	 /*
	  * PRE: { La variable "codigoVia" y el puntero a la referencia de "v"
	  *        deben estar inicializados correctamente }
	  * POST:{ Busca la via que coincide con el contenido de la variable
	  *        "codigoVia" y devuelve un puntero que apunta a dicha via }
	  * COMPLEJIDAD:O(n²)
	  */
   void BuscarVias(int codigoVia, Via *&v);

	 /*
	  * PRE: { La variable "nombreVia" inicializada correctamente }
	  * POST:{ Crea un fichero que muestra los arboles de la via introducida
		*        por teclado }
	  * COMPLEJIDAD:O(n²*log(n))
	  */
	 void ficheroArboles(string nombreVia);//ALGORITMO 1

	 /*
	  * PRE: { La variable "especie" inicializada correctamente }
	  * POST:{ Crea un fichero  con el nombre de las vías en la que existan
		*        árboles de una determinada especie }
	  * COMPLEJIDAD:O(n³)
	  */
	 void ficheroEspecies(string especie);//ALGORITMO 2

	 /*
	  * PRE: { La variable "genero" y el puntero "viasgenero" inicializado correctamente }
	  * POST:{ Inserta en el arbol apuntado por "viasgenero" todas las vías que contengan
		*        árboles de un determinado género }
	  * COMPLEJIDAD:O()
	  */
   void SubArbol(ArbolB<Via*, Comparar> *&viasgenero, string genero);//ALGORITMO 3

	 /*
	 * PRE: { La variable "subcadena" inicializado correctamente }
	 * POST:{ Crea un fichero que muestra los arboles de la via introducida
	 *        por teclado }
	 * COMPLEJIDAD:O()
	 */
   void ficheroSubCadena(string subcadena);//ALGORITMO 4
	/*
	* PRE: {}
	* POST:{ Destructor por defecto }
	* COMPLEJIDAD:O(n²)
	*/
   ~Algoritmos();

};

#endif /* ALGORITMOS_H_ */
