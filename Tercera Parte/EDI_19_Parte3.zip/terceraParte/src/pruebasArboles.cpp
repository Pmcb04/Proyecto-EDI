/*
 * pruebasArboles.cpp
 *
 *  Created on: 18 feb. 2019
 *      Authors:  - Pedro Miguel Carmona Broncano
 									- Ruben Marin Lucas
 */

#include "pruebasArboles.h"

const float ERROR = 0.01;

void pruebasArboles(){


cout << "-------------INICIO PRUEBA ARBOLES--------------" << endl;

  pruebasPorDefectoA();
  pruebasParametrizadoA();
  pruebasSetGetA();

	cout << "-------------FIN PRUEBA ARBOLES-----------------" << endl;

}

void pruebasPorDefectoA(){

  cout << "-------------INICIO PRUEBA ARBOLES POR DEFECTO --------------" << endl;

  Arbol *a;

  // 1º PRUEBA (CONSTRUCTOR POR DEFECTO)

  a = new Arbol();

  if(a->getEspecie() != "")
    cout << "ERROR en atributo especie (constructor por defecto)" << endl;

  if(a->getFamilia() != "")
    cout << "ERROR en atributo familia (constructor por defecto)" << endl;

  if(a->getNombreComun() != "")
    cout << "ERROR en atributo nombreComun (constructor por defecto)" << endl;

  if(a->getGenero() != "")
  	cout << "ERROR en atributo genero (constructor por defecto)" << endl;

  if(a->getRiego() != "")
  	cout << "ERROR en atributo riego (constructor por defecto)" << endl;

  if(a->getDiametro() != 0.0)
    cout << "ERROR en atributo diametro (constructor por defecto)" << endl;

  if(a->getAltura() != 0.0)
  	cout << "ERROR en atributo altura (constructor por defecto)" << endl;

  if(a->getCopa() != 0.0)
    cout << "ERROR en atributo copa (constructor por defecto)" << endl;

  if(a->getUnidades() != 0)
  	cout << "ERROR en atributo unidades (constructor por defecto)" << endl;

  if(a->getCodigoVia() != 0)
  	cout << "ERROR en atributo codigoVia (constructor por defecto)" << endl;

  delete a;

    cout << "-------------FIN PRUEBA ARBOLES POR DEFECTO --------------" << endl;
}

void pruebasParametrizadoA(){

  cout << "-------------INICIO PRUEBA ARBOLES PARAMETRIZADO--------------" << endl;

  Arbol *a;

  // 2º PRUEBA (CONSTRUCTOR PARAMETRIZADO)

  a = new Arbol("Acer_negundo", "Aceraceae", "ARCE DE HOJAS DE FRESNO",
                "ACER", 0.05, 5, 3, "NO RIEGO", 1, 3660);

  if(a->getEspecie() != "Acer_negundo")
    cout << "ERROR en atributo especie (constructor parametrizado)" << endl;

  if(a->getFamilia() != "Aceraceae")
    cout << "ERROR en atributo familia (constructor parametrizado)" << endl;

  if(a->getNombreComun() != "ARCE DE HOJAS DE FRESNO")
    cout << "ERROR en atributo nombreComun (constructor parametrizado)" << endl;

  if(a->getGenero() != "ACER")
  	cout << "ERROR en atributo genero (constructor parametrizado)" << endl;

  if(a->getRiego() !=  "NO RIEGO")
  	cout << "ERROR en atributo riego (constructor parametrizado)" << endl;

  if(a->getDiametro() > (0.05 + ERROR))
    cout << "ERROR en atributo diametro (constructor parametrizado)" << endl;

  if(a->getAltura() > (5 + ERROR))
  	cout << "ERROR en atributo altura (constructor parametrizado)" << endl;

  if(a->getCopa() > (3 + ERROR))
    cout << "ERROR en atributo copa (constructor parametrizado)" << endl;

  if(a->getUnidades() != 1)
  	cout << "ERROR en atributo unidades (constructor parametrizado)" << endl;

  if(a->getCodigoVia() != 3660)
  	cout << "ERROR en atributo codigoVia (constructor parametrizado)" << endl;

  delete a;

  cout << "-------------FIN PRUEBA ARBOLES PARAMETRIZADO--------------" << endl;


}

void pruebasSetGetA(){

  cout << "-------------INICIO PRUEBA ARBOLES SET / GET --------------" << endl;

  Arbol *a;

  //3º PRUEBA METODOS SET/GET

  a = new Arbol();

  a->setEspecie("Acer_sacharinum");
  a->setFamilia("Aceraceae");
  a->setNombreComun("ARCE PLATEADO");
  a->setGenero("ACER");
  a->setRiego("MANUAL");
  a->setDiametro(0.06);
  a->setAltura(3.5);
  a->setCopa(2.5);
  a->setUnidades(1);
  a->setCodigoVia(3614);

  if(a->getEspecie() != "Acer_sacharinum")
    cout << "ERROR en atributo especie (SET/GET)" << endl;

  if(a->getFamilia() != "Aceraceae")
    cout << "ERROR en atributo familia (SET/GET)" << endl;

  if(a->getNombreComun() != "ARCE PLATEADO")
    cout << "ERROR en atributo nombreComun (SET/GET)" << endl;

  if(a->getGenero() != "ACER")
  	cout << "ERROR en atributo genero (SET/GET)" << endl;

  if(a->getRiego() !=  "MANUAL")
  	cout << "ERROR en atributo riego (SET/GET)" << endl;

  if(a->getDiametro() > (0.06 + ERROR))
    cout << "ERROR en atributo diametro (SET/GET)" << endl;

  if(a->getAltura() > (3.5 + ERROR))
  	cout << "ERROR en atributo altura (SET/GET)" << endl;

  if(a->getCopa() > (2.5 + ERROR))
    cout << "ERROR en atributo copa (SET/GET)" << endl;

  if(a->getUnidades() != 1)
  	cout << "ERROR en atributo unidades (SET/GET)" << endl;

  if(a->getCodigoVia() != 3614)
  	cout << "ERROR en atributo codigoVia (SET/GET)" << endl;

  delete a;

  cout << "-------------FIN PRUEBA ARBOLES SET / GET --------------" << endl;


}
