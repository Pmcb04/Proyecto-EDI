/*
 * Algoritmos.cpp
 *
 *  Created on: 02/03/2019
 *      Author: Profesores de EDI
 */

#include <fstream>
#include <iostream>

#include "algoritmos.h"


using namespace std;

// MAIN function
int main () {
    Algoritmos Algoritmos;
}


// ******************** PRIVATE OPERATIONS ********************


void Algoritmos::run() {

	// TODO invovar a todos los algoritmos para que se ejecuten secuencialemente
	mostrarBarrios();

    // Algoritmo 1

    // Algoritmo 2

    // Algoritmo 3

    // Algoritmo 4


}

void Algoritmos::cargarDatos() {
	// TODO realizar la lectura del fichero de barrios y después el de vías
}





// ******************** PUBLIC INTERFACE ********************


Algoritmos::Algoritmos() {
    
    cout << "Programming Project v1.00 (EDI)." << endl;
    cout << "           Author: xx xx xx." << endl;
    cout << "           Date:   March 8th, 2019." << endl;
    


    cjtoBarrios = new SetBarrios();
    this->cargarDatos();
    this->run();
}






Algoritmos::~Algoritmos() {

    // Complete memory deallocation

    delete cjtoBarrio;
}


