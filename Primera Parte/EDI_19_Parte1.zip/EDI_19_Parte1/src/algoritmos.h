/*
 * Algoritmos.h
 *
 *  Created on: 02/03/2019
 *      Author: Profesores de EDI
 */

#ifndef ALGORITMOS_H_
#define ALGORITMOS_H_

#include "SetBarrios.h"
#include "SetVias.h"

class Algoritmos {

private:

    // TODO atributo, puntero a la clase conjunto de barrios
	SetBarrios *cjtoBarrios;

	// carga los datos desde los ficheros de texto
	void cargarDatos();
    // ejecuta todos los algoritmos del proyecto
	void run ();

public:

	 Algoritmos();
	 // Algoritmo 0 (ejemplo), muestra todos los barrios con sus vías
	 void mostrarBarrios();

    void ficheroVias();
	 void barriosMaxMin();
	 void barrioSubcadena();
	 void mayorAvenida();

	 ~Algoritmos();

};

#endif /* ALGORITMOS_H_ */
