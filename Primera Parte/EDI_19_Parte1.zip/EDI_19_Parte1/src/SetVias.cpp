/*
 * setVias.cpp
 *
 *  Created on: 4 mar. 2019
 *      Author: pedro
 */

#include "SetVias.h"

#include <iostream>
using namespace std;

SetVias::SetVias() {

	cont = 0;
}

SetVias::~SetVias() {

	for (int i = 0; i < cont; i++) {

		delete setVias[i];

	}
}


bool SetVias::estaVacia() {

	return cont == 0;

}

int SetVias::numElementos() {

	return cont;

}

void SetVias::insertar(Via* v) {

		int i = 0;
		bool enc = false;

		while (i < cont && !enc){

			if(setVias[i]->getClave() > v->getClave()){

				enc = true;

			}else{

				i++;

			}

		}


		if(enc){

			for (int j = cont; j > i; j--) {

				setVias[j] = setVias[j-1];

			}

		}

		setVias[i] = v;
		cont++;

}

bool SetVias::existe(string clave) {

	bool existe = false;
	int i = 0;

	while(i < cont && !existe){

		if(setVias[i]->getClave() == clave){

			existe = true;
		}

		i++;
	}

	return existe;

}

void SetVias::get(int pos, Via*& v) {

	v = setVias[pos];
}

void SetVias::get(string clave, Via*&v) {

	bool enc = false;
	int i = 0;

	while(i < cont && !enc){

		if(setVias[i]->getClave() == v->getClave()){

			v = setVias[i];
			enc = true;
		}

		i++;
	}

}

void SetVias::eliminar(string clave) {


	int i = 0;
	bool enc = false;

	while(i < cont && !enc){

		if(setVias[i]->getClave() == clave){

			enc = true;

		}else{

			i++;

		}

	}

	if(enc){

		for (int j = i; j < cont ; j++){

			setVias[j] = setVias[j+1];

	}

		cont--;

	}

}

void SetVias::mostrar() {

		for (int i = 0; i < cont; i++) {

			cout << endl;
			cout << "Codigo del barrio: " << setVias[i]->getCodigoBarrio() << endl;
			cout << "Nombre de la via: " << setVias[i]->getNombreVia() << endl;
			cout << "Longitud de la via: " << setVias[i]->getLongitudVia() << endl;
			cout << "Tipo de la via: " << setVias[i]->getTipoVia() << endl;
			cout << "Codigo de la via: " << setVias[i]->getCodigoVia() << endl;

			cout << endl;
		}




}
