/*
 * setBarrios.h
 *
 *  Created on: 11 mar. 2019
 *      Author: pedro
 */

#ifndef SETBARRIOS_H_
#define SETBARRIOS_H_

#include "Barrio.h"

const int MAX_BARRIOS = 80;


class SetBarrios {

private:

	Barrio *setBarrios[MAX_BARRIOS];
	int cont;


public:

	/*
	 * PRE: {  }
	 * POST:{ Inicializa el atributo -cont- con valor 0 }
	 * COMPLEJIDAD:O(1)
	 */
	SetBarrios();

	/*
	 * PRE: {  }
	 * POST:{ Destruye todos los elementos de la estructura }
	 * COMPLEJIDAD:O(n)
	 */
	~SetBarrios();

	/*
	 * PRE: { }
	 * POST:{ Devuelve true en caso de estar la estructura vacia y false en caso contrario }
	 * COMPLEJIDAD:O(1)
	 */
	bool estaVacia();

	/*
	 * PRE: {  }
	 * POST:{ Devuelve el contenideo del atributo -cont- }
	 * COMPLEJIDAD:O(1)
	 */
	int numElementos();

	/*
	 * PRE: { "b" correctamente inicializada }
	 * POST:{ Inserta el barrio "b" en la estructura}
	 * COMPLEJIDAD:O(n)
	 */
	void insertarBarrios(Barrio *b);

	/*
	 * PRE: { Existe el nombre del conjunto }
	 * POST:{ Devuelve true en caso de existir por "nombre" el barrio en la estructura
  					y false en caso contrario }
	 * COMPLEJIDAD:O(n)
	 */
	bool existeBarrio(string nombre);


	/*
	 * PRE: { 0 <= pos < cont , el puntero v debe estar
	 * 				correctamente inicializado}
	 * POST:{ Devuelve el barrio "b" que se encuentra en la posición "pos"}
	 * COMPLEJIDAD:O(1)
	 */
	void get (int pos, Barrio *&b);

	/*
	 * PRE: { Existe la clave del conjunto y el puntero v debe estar
	 * 				correctamente inicializado}
	 * POST:{ Devuelve el barrio encontrado por "nombre" en "b"}
	 * COMPLEJIDAD:O(n)
	 */
	void get (string nombre, Barrio *&b);

	/*
	 * PRE: { Existe la clave del conjunto}
	 * POST:{ Elimina la via que conincida su clave de la estructura }
	 * COMPLEJIDAD:O(n)
	 */
	void eliminar(string clave);

	/*
	 * PRE: { El/los Barrio/s de la estructura deben estar inicializados }
	 * POST:{ Muestra por pantalla todas los barrios de la estructura}
	 * COMPLEJIDAD:O(n)
	 */
	void mostrar();


};

#endif /* SETBARRIOS_H_ */
