/*
 * Conjunto.h
 *
 *  Created on: 12 mar. 2019
 *      Author: pedro
 */

#ifndef CONJUNTO_H_
#define CONJUNTO_H_

#include <iostream>
using namespace std;

const int MAX = 80;

template <class T>

class Conjunto {

private:

	T *setConjunto[MAX];
	int cont;

public:
	Conjunto();
	~Conjunto();

	bool estaVacia();
	int numElementos();
	void insertarElemento(T *t);
	bool existe(string nombre);

	//PRE : { 0 <= pos < cont}
	void get(int pos, T *&t);

	//PRE : { existe la clave del conjunto}
	void get(string clave, T *&t);

	void eliminar(string clave);

	//mostrar para comprobar que los datos son correctos
	void mostrar();

};

#endif /* CONJUNTO_H_ */
