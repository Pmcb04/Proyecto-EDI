/*
 * Algoritmos.cpp
 *
 *  Created on: 02/03/2019
 *      Author: Profesores de EDI
 */

#include <fstream>
#include <iostream>

#include "algoritmos.h"
#include "pruebasAlgortimos.h"


using namespace std;

// MAIN function
int main () {
    Algoritmos Algoritmos;
}


// ******************** PRIVATE OPERATIONS ********************

void Algoritmos::ficheroVias(){

    string nombreBarrio;
    bool enc = false;

    while(!enc){

        cout << "Introduce el nombre de un barrio: "  << endl;
        getline(cin, nombreBarrio);

        if(cjtoBarrios->existeBarrio(nombreBarrio)){

            enc = true;

        }else{

          cout << "El nombre introducido no corresponde a ningun barrio." << endl;

        }

    }

        Barrio *b;
        cjtoBarrios->get(nombreBarrio, b);

        b->ficheroVias();


}

void Algoritmos::barriosMaxMin(){

    Barrio *b;
    int mayor, menor;

    cjtoBarrios->get(0, b);
    mayor = b->getNumElementosVias();

    cjtoBarrios->get(1, b);

    menor = b->getNumElementosVias();

    if(mayor < menor){

        int *aux = new int;

        *aux = menor;
        menor = mayor;
        mayor = *aux;

        delete aux;

    }

    for (int i = 2; i < cjtoBarrios->numElementos(); i++){

        cjtoBarrios->get(i, b);

        if(!b->estaVacio()){

            if (b->getNumElementosVias() > mayor){

                    mayor = b->getNumElementosVias();

            }else if (b->getNumElementosVias() < menor){

                    menor = b->getNumElementosVias();

            }

        }else{

          menor = 0;

        }

    }



    cout << "------------ Barrios con numero de vias menor (" << menor << "):---------------------" << endl << endl;

            for (int i = 0; i < cjtoBarrios->numElementos(); i++){

                cjtoBarrios->get(i, b);

                if(b->estaVacio() && menor == 0){

                  b->mostrar();


                } else if(!b->estaVacio() && b->getNumElementosVias() == menor){

                        b->mostrar();

                }

            }

    cout << "------------ Barrios con numero de vias mayor (" << mayor << "):--------------------" << endl << endl;

            for (int i = 0; i < cjtoBarrios->numElementos(); i++){

                cjtoBarrios->get(i, b);

                if(!b->estaVacio() && b->getNumElementosVias() == mayor){

                    b->mostrar();

                }

            }

}


void Algoritmos::barrioSubcadena(){

    string subcadena;
    Barrio *b;

    cout << "Introduce subcadena: "  << endl;
    getline(cin, subcadena);

    for (int i = 0; i < cjtoBarrios->numElementos(); i++){

        cjtoBarrios->get(i, b);

        if(b->getNombre().find(subcadena) == 0){

            b->mostrar();

        }
    }

}

void Algoritmos::mayorAvenida(){

    Barrio *b;
    Via *v;
    Via *aux;

    for (int i = 0; i < cjtoBarrios->numElementos(); i++){

        cjtoBarrios->get(i, b);

        if(!b->estaVacio()){

            b->MaxAvenida(aux);

            if(aux->getLongitudVia() > v->getLongitudVia()){

                v = aux;

            }



        }

    }

    int i = 0;
    bool enc = false;

    while(i < cjtoBarrios->numElementos() && !enc){

        cjtoBarrios->get(i, b);

        if(b->getCodigo() == v->getCodigoBarrio()){

            enc = true;

        }

        i++;

    }

    cout << "La Avda de mayor longitud de Cáceres es: " << v->getNombreVia() << endl;
    cout << "Con una longitud de: " << v->getLongitudVia() << endl;
    cout << "Perteneciente al distrito: " << b->getDistrito() << endl;


}

void Algoritmos::run() {


//	mostrarBarrios();

//  ficheroVias();

//  barriosMaxMin();

  barrioSubcadena();

//  mayorAvenida();

  pruebasAlgoritmos(cjtoBarrios);


}

void Algoritmos::cargarDatos() {

    Barrio *b;
    string linea;
    string campo[5];

    fstream flujoEntrada;
    flujoEntrada.open("Barrio.csv");

    if(!flujoEntrada.eof()){

        getline(flujoEntrada, linea);

        while(!flujoEntrada.eof()){

            for (int i = 0; i < 4; i++){

                getline(flujoEntrada, campo[i], ';');
            }

            getline(flujoEntrada, campo[4]);

            if (!flujoEntrada.eof()){

                b = new Barrio(campo[0], atof(campo[1].c_str()), atof(campo[2].c_str()),  atoi(campo[3].c_str()), campo[4]);
                cjtoBarrios->insertarBarrios(b);

            }

        }

        flujoEntrada.close();

    }

}


// ******************** PUBLIC INTERFACE ********************


Algoritmos::Algoritmos() {

    cout << "Programming Project v1.00 (EDI)." << endl;
    cout << "           Author: xx xx xx." << endl;
    cout << "           Date:   March 8th, 2019." << endl;



    cjtoBarrios = new SetBarrios();
    this->cargarDatos();
    this->run();
}


void Algoritmos::mostrarBarrios(){

    Barrio *b;

    for (int i = 0; i < cjtoBarrios->numElementos(); i++){

        cjtoBarrios->get(i,b);

        	 b->mostrar();

    }
}


Algoritmos::~Algoritmos() {

    // Complete memory deallocation

    delete cjtoBarrios;
}
