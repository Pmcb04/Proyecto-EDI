/*
 * Conjunto.cpp
 *
 *  Created on: 12 mar. 2019
 *      Author: pedro
 */

#include "Conjunto.h"

template <class T> Conjunto <T>::Conjunto() {
	// TODO Auto-generated constructor stub

    cont = 0;

}


template <class T> Conjunto <T>::~Conjunto() {
	// TODO Auto-generated destructor stub

    for(int i = 0; i < cont; i++){

        delete setConjunto[i];

    }

}

template<class T>
inline bool Conjunto<T>::estaVacia() {

	 return cont == 0;
}

template<class T>
inline int Conjunto<T>::numElementos() {

	return cont;
}

template<class T>
inline void Conjunto<T>::insertarElemento(T* t) {

    int i = 0;
    bool enc = false;

    while (i < cont && !enc){

        if(setConjunto[i]->getNombre() > t->getNombre()){

            enc = true;

        }else{

            i++;

        }

    }


    if(enc){

        for (int j = cont; j > i; j--) {

            setConjunto[j] = setConjunto[j-1];

        }

    }

    setConjunto[i] = t;
    cont++;


}

template<class T>
inline bool Conjunto<T>::existe(string nombre) {

    bool existe = false;
    int i = 0;

    while(i < cont && !existe){

        if(setConjunto[i]->getNombre() == nombre){

            existe = true;
        }

        i++;
    }

    return existe;


}

template<class T>
inline void Conjunto<T>::get(int pos, T*& t) {

    t = setConjunto[pos];
}

template<class T>
inline void Conjunto<T>::get(string clave, T*& t) {

    bool enc = false;
    int i = 0;

    while(i < cont && !enc){

        if(setConjunto[i]->getClave() == t->getClave()){

            t = setConjunto[i];
            enc = true;
        }

        i++;
    }

}

template<class T>
inline void Conjunto<T>::eliminar(string clave) {

    int i = 0;
    bool enc = false;

    while(i < cont && !enc){

        if(setConjunto[i]->getClave() == clave){

            enc = true;

        }else{

            i++;

        }

    }

    if(enc){

        for (int j = i; j < cont ; j++){

            setConjunto[j] = setConjunto[j+1];

    }

        cont--;

    }


}

template<class T>
inline void Conjunto<T>::mostrar() {

    for (int i = 0; i < cont; i++) {

        cout << endl;
        cout << "Codigo del barrio: " << setConjunto[i]->getCodigoBarrio() << endl;
        cout << "Nombre de la via: " << setConjunto[i]->getNombreVia() << endl;
        cout << "Longitud de la via: " << setConjunto[i]->getLongitudVia() << endl;
        cout << "Tipo de la via: " << setConjunto[i]->getTipoVia() << endl;
        cout << "Codigo de la via: " << setConjunto[i]->getCodigoVia() << endl;
        cout << endl;
    }


}
