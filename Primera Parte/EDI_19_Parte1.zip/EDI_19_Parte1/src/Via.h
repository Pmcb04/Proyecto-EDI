/*
 * Via.h
 *
 *  Created on: 25 feb. 2019
 *      Authors:  - Pedro Miguel Carmona Broncano
 									- Ruben Marin Lucas
 */

#ifndef VIA_H_
#define VIA_H_

#include <iostream>
using namespace std;

class Via {

private:

	int codigoBarrio;
	int codigoVia;
	float longitudVia;
	string nombreVia;
	string tipoVia;


public:


	/*
	 * PRE: {  }
	 * POST:{ Constructor por defecto }
	 * COMPLEJIDAD:O(1)
	 */
	Via();

	/*
	 * PRE: {  }
	 * POST:{ Constructor parametrizado }
	 * COMPLEJIDAD:O(1)
	 */
	Via(int codigoBarrio, string nombreVia, float longitudVia, string tipoVia, int codigoVia);

	/*
	 * PRE: {  }
	 * POST:{ Destructor por defecto }
	 * COMPLEJIDAD:O(1)
	 */
	~Via();

	//metodos setter

	/*
	 * PRE: { La variable "codigoBarrio" inicializada correctamente }
	 * POST:{ Introduce el contenido de la
	 *       variable "codigoBrrio" en el atributo -codigoBarrio- }
	 * COMPLEJIDAD:O(1)
	 */
	void setCodigoBarrio(int codigoBarrio);

	/*
	 * PRE: { La variable "codigoVia" inicializada correctamente }
	 * POST:{ Introduce el contenido de la
	 *       variable "codigovias" en el atributo -codigoVia- }
	 * COMPLEJIDAD:O(1)
	 */
	void setCodigoVia(int codigoVia);

	/*
	 * PRE: { La variable "longitudVia" inicializada correctamente }
	 * POST:{ Introduce el contenido de la
	 *       variable "longitudVia" en el atributo -longitudVia- }
	 * COMPLEJIDAD:O(1)
	 */
	void setLongitudVia(float longitudVia);

	/*
	 * PRE: { La variable "nombreVia" inicializada correctamente }
	 * POST:{ Introduce el contenido de la
	 *       variable "nombreVia" en el atributo -nombreVia- }
	 * COMPLEJIDAD:O(1)
	 */
	void setNombreVia(string nombreVia);

	/*
	 * PRE: { La variable "tipoVia" inicializada correctamente }
	 * POST:{ Introduce el contenido de la
	 *       variable "tipoVia" en el atributo -tipoVia- }
	 * COMPLEJIDAD:O(1)
	 */
	void setTipoVia(string tipoVia);

	//metodos getter


	/*
	 * PRE: { La via  debe tener el atributo -codigoBarrio- inicializado }
	 * POST:{ Devuelve el contenido del atributo -codigoBarrio- }
	 * COMPLEJIDAD:O(1)
	 */
	int getCodigoBarrio();

	/*
	 * PRE: { La via  debe tener el atributo -codigoVia- inicializado }
	 * POST:{ Devuelve el contenido del atributo -codigoVia- }
	 * COMPLEJIDAD:O(1)
	 */
	int getCodigoVia();

	/*
	 * PRE: { La via debe tener el atributo -longitud- inicializado }
	 * POST:{ Devuelve el contenido del atributo -longitud- }
	 * COMPLEJIDAD:O(1)
	 */
	float getLongitudVia();

	/*
	 * PRE: { La via debe tener el atributo -nombreVia- inicializado }
	 * POST:{ Devuelve el contenido del atributo -nombreVia- }
	 * COMPLEJIDAD:O(1)
	 */
	string getNombreVia();

	/*
	 * PRE: { La via debe tener el atributo -tipoVia- inicializado }
	 * POST:{ Devuelve el contenido del atributo -tipoVia- }
	 * COMPLEJIDAD:O(1)
	 */
	string getTipoVia();

	/*
	 * PRE: { La via debe tener el atributo -codigoBarrio- y -codigoVia- inicializados }
	 * POST:{ Devuelve codigoBarrio + codigoVia}
	 * COMPLEJIDAD:O(1)
	 */
	string getClave();

	/*
	 * PRE: { La via debe estar inicializado }
	 * POST:{ Muestra por pantalla la información de la via }
	 * COMPLEJIDAD:O(1)
	 */
	void mostrar();

};

#endif /* VIA_H_ */
