
#ifndef PRUEBASALGORITMOS_H_
#define PRUEBASALGORITMOS_H_

#include <fstream>
#include <iostream>
#include "SetVias.h"
#include "SetBarrios.h"
using namespace std;


void pruebaFicheroVias(SetBarrios *&cjtoBarrios);
void pruebaBarriosMaxMin();
void pruebaBarrioSubcadena();
void pruebaMayorAvenida();
void pruebasAlgoritmos(SetBarrios *&cjtoBarrios);


#endif /* PRUEBASALGORITMOS_H_ */
