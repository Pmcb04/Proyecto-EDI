/*
 * Barrio.h
 *
 *  Created on: 18 feb. 2019
 *      Authors:  - Pedro Miguel Carmona Broncano
 									- Ruben Marin Lucas
 */



#ifndef BARRIO_H_
#define BARRIO_H_

#include <string>
#include <iostream>
#include "SetVias.h"
using namespace std;

class Barrio {

private:

	string nombre;
	string nombreDistrito;
	float area;
	float perimetro;
	int codigo;
	SetVias *conjuntoVias;

	void cargarVias();


public:


	/*
	 * PRE: {}
	 * POST:{ Constructor por defecto }
	 * COMPLEJIDAD:O(1)
	 */
	Barrio();

	/*
	 * PRE: {}
	 * POST:{ Construye el barrio con los parametros introducidos }
	 * COMPLEJIDAD:O(1)
	 */
	Barrio(string nombre, float area, float perimetro, int codigo, string distrito);


	/*
	 * PRE: {}
	 * POST:{ Destructor por defecto }
	 * COMPLEJIDAD:O(1)
	 */
	~Barrio();

	//metodos settter


	/*
	 * PRE: { La variable "nombre" inicializada correctamente }
	 * POST:{ Introduce el contenido de la
	 *       variable "nombre" en el atributo -nombre- }
	 * COMPLEJIDAD:O(1)
	 */
	void setNombre(string nombre);

	/*
	 * PRE: { La variable "area" inicializada correctamente }
	 * POST:{ Introduce el contenido de la
	 *       variable "area" en el atributo -area- }
	 * COMPLEJIDAD:O(1)
	 */
	void setArea(float area);

	/*
	 * PRE: { La variable "perimetro" inicializada correctamente }
	 * POST:{ Introduce el contenido de la
	 *       variable "perimetro" en el atributo -perimetro- }
	 * COMPLEJIDAD:O(1)
	 */
	void setPerimetro(float perimetro);

	/*
	 * PRE: { La variable "distrito" inicializada correctamente }
	 * POST:{ Introduce el contenido de la
	 *       variable "distrito" en el atributo -distrito- }
	 * COMPLEJIDAD:O(1)
	 */
	void setDistrito(string distrito);

	/*
	 * PRE: { La variable "codigo" inicializada correctamente }
	 * POST:{ Introduce el contenido de la
	 *       variable "codigo" en el atributo -codigo- }
	 * COMPLEJIDAD:O(1)
	 */
	void setCodigo(int codigo);

	/*
	 * PRE: {El barrio debe estar inicializado}
	 * POST:{ Muestra por pantalla la información del barrio y la
	 					de todas sus calles }
	 * COMPLEJIDAD:O(1)
	 */

	void mostrar();

	/*
	 * PRE: { Las vias pertenecientes a este barrio deben estar
	 				leidas y almacenadas en -conjuntoVias- }
	 * POST:{ Crea un fichero llamado "ficheroVias.txt" donde muestra
	  				todos los nombres de las calles pertenecientes a este barrio}
	 * COMPLEJIDAD:O(n)
	 */

	void ficheroVias();


	//Metodos Getter

	/*
	 * PRE: { El barrio debe tener el atributo -nombre- inicializado }
	 * POST:{ Devuelve el contenido del atributo -nombre- }
	 * COMPLEJIDAD:O(1)
	 */
	string getNombre();

	/*
	 * PRE: { El barrio debe tener el atributo -nombre- inicializado  y
	 *         la variable "nombre" debe estar inicializada correctamente }
	 * POST:{ Devuelve el contenido del atributo -nombre- en la variable de entrada
	 					y salida "nombre" }
	 * COMPLEJIDAD:O(1)
	 */
	void getNombre(string &nombre);

	/*
	 * PRE: {}
	 * POST:{ Devuelve true si el -conjuntoVias- esta vacia y false en caso contrario }
	 * COMPLEJIDAD:O(1)
	 */
	bool estaVacio();

	/*
	 * PRE: { El barrio debe tener el atributo -area- inicializado }
	 * POST:{ Devuelve el contenido del atributo -area- }
	 * COMPLEJIDAD:O(1)
	 */
	float getArea();

	/*
	 * PRE: { El barrio debe tener el atributo -perimetro- inicializado }
	 * POST:{ Devuelve el contenido del atributo -perimetro- }
	 * COMPLEJIDAD:O(1)
	 */
	float getPerimetro();

	/*
	 * PRE: { El barrio debe tener el atributo -codigo- inicializado }
	 * POST:{Devuelve el contenido del atributo -codigo- }
	 * COMPLEJIDAD:O(1)
	 */
	int getCodigo();

	/*
	* PRE: { El barrio debe tener el atributo -nombreDistrito- inicializado }
	* POST:{Devuelve el contenido del atributo -nombredistrito- }
	* COMPLEJIDAD:O(1)
	*/
	string getDistrito();

	/*
	 * PRE: { El barrio debe tener el atributo -conjuntoVias- inicializado }
	 * POST:{ Devuelve el numero de vias que hay en -conjuntoVias- }
	 * COMPLEJIDAD:O(1)
	 */
	int getNumElementosVias();

	/*
	 * PRE: { El puntero "via" debe estar inicializado correctamente }
	 * POST:{ Inserta la via a la que esta apuntado "via" en -conjuntoVias- }
	 * COMPLEJIDAD:O(1)
	 */
	void insertarVia(Via *via);

	/*
	 * PRE: { -conjuntoVias- contenga al menos un elemento }
	 * POST:{ Devuelve la suma de todas las longitudes de las vias que existen en -conjuntoVias- }
	 * COMPLEJIDAD:O(n)
	 */
	float longitudTotalVias();


	/*
	* PRE: { La variable "nombre" y el puntero "via" deben estar }
	* POST:{ Devuelve true en el caso de encontrar la via especificada y false en caso contrario }
	* COMPLEJIDAD:O(n)
	*/
	bool buscarVia(string nombre, Via *&v);


	/*
	* PRE: { La variable "codigo" debe estar correctamente inicilizada}
	* POST:{ Devuelve true en el caso de que exista un barrio que contenga
	* en su atributo -codigo- el contenido de la variable "codigo" y false en caso contrario}
	* COMPLEJIDAD:O(1)
	*/
	bool existeBarrio(int codigo);

	/*
	* PRE: { "v" declarada correctamente}
	* POST:{ Devuelve en "v" la via que es de tipo Avda de mayor longitud del -conjuntoVias-
					 En caso de no encontrar ninguna via, devolvería una via con longitud 0.0}
	* COMPLEJIDAD:O(1)
	*/
	void MaxAvenida(Via *&v);

};

#endif /* BARRIO_H_ */
