/*
 * setVias.h
 *
 *  Created on: 4 mar. 2019
 *      Author: pedro
 */

#ifndef SETVIAS_H_
#define SETVIAS_H_

#include "Via.h"

const int MAX_VIAS = 50;

class SetVias {

private:

	Via *setVias[MAX_VIAS];
	int cont;

public:

	/*
	 * PRE: {  }
	 * POST:{ Inicializa el atributo -cont- con valor 0 }
	 * COMPLEJIDAD:O(1)
	 */
	SetVias();

	/*
	 * PRE: {  }
	 * POST:{ Destruye todos los elementos de la estructura }
	 * COMPLEJIDAD:O(n)
	 */
	~SetVias();

	/*
	 * PRE: { }
	 * POST:{ Devuelve true en caso de estar la estructura vacia y false en caso contrario }
	 * COMPLEJIDAD:O(1)
	 */
	bool estaVacia();

	/*
	 * PRE: {  }
	 * POST:{ Devuelve el contenideo del atributo -cont- }
	 * COMPLEJIDAD:O(1)
	 */
	int numElementos();

	/*
	 * PRE: { "v" correctamente inicializada }
	 * POST:{ Inserta la via "v" en la estructura}
	 * COMPLEJIDAD:O(n)
	 */
	void insertar(Via *v);

	/*
	 * PRE: { Existe la clave del conjunto }
	 * POST:{ Devuelve true en caso de existir por "clave" la via en la estructura
  					y false en caso contrario }
	 * COMPLEJIDAD:O(n)
	 */
	bool existe(string clave);

	/*
	 * PRE: { 0 <= pos < cont , el puntero v debe estar
	 * 				correctamente inicializado}
	 * POST:{ Devuelve la via "v" que se encuentra en la posición "pos"}
	 * COMPLEJIDAD:O(1)
	 */
	void get (int pos, Via *&v);

	/*
	 * PRE: { Existe la clave del conjunto y el puntero v debe estar
	 * 				correctamente inicializado}
	 * POST:{ Devuelve la via encontrada por "clave" en "v"}
	 * COMPLEJIDAD:O(n)
	 */
	void get (string clave, Via *&v);

	/*
	 * PRE: { Existe la clave del conjunto}
	 * POST:{ Elimina la via que conincida su clave de la estructura }
	 * COMPLEJIDAD:O(n)
	 */
	void eliminar(string clave);

	/*
	 * PRE: {La/s Via/s de la estructura deben estar inicializado }
	 * POST:{ Muestra por pantalla todas las vias de la estructura}
	 * COMPLEJIDAD:O(n)
	 */
	void mostrar();
};

#endif /* SETVIAS_H_ */
