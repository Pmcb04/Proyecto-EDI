
#include "pruebasAlgortimos.h"

void pruebaFicheroVias(SetBarrios *&cjtoBarrios){

  cout << "--------------- INICIO PRUEBA FICHERO VIAS ---------------" << endl;

  fstream prueba;
  prueba.open("ficheroVias.txt");

  string basura1, basura2, barrio, via;
  Barrio *b;
  Via *v;

  if(!prueba.eof()){

    getline(prueba, basura1, '%');
    getline(prueba, barrio, '%');
    getline(prueba, basura2);

 //    cout << barrio << endl;

  if(cjtoBarrios->existeBarrio(barrio)){

    while(!prueba.eof()){

      cjtoBarrios->get(barrio, b);
      getline(prueba, via);

      if(!b->buscarVia(via, v) && !prueba.eof()){

        cout << "ERROR Via " + via + " not found" << endl;

      }

    }

  }else{

    cout << "ERROR Barrio " + barrio + " not found" << endl;

  }

    prueba.close();

  }

  cout << "--------------- FIN PRUEBA FICHERO VIAS ---------------" << endl;



}

void pruebaBarriosMaxMin(){

  // comprobar que esos barrios son los que menos y mas tienen de vias


}

void pruebaBarrioSubcadena(){

  // comprobar que los barrios mostrados tienen esa subcadena





}

void pruebaMayorAvenida(){

  // le pasamos el puntero apuntando a la via de tipo Avda con mas longitud
  // y comprobamos si esa via es la mas larga


}

void pruebasAlgoritmos(SetBarrios *&cjtoBarrios){

  pruebaFicheroVias(cjtoBarrios);
  pruebaBarriosMaxMin();
  pruebaBarrioSubcadena();
  pruebaMayorAvenida();


}
